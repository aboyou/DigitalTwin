from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

from author_analysis.analyzer import BibliometricAnalyzer
from author_analysis.config import AnalysisConfig
from author_analysis.exporters import Exporter
from author_analysis.visualization import Visualizer


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Analyze authors_json in a SQLite articles table and generate bibliometric, Gephi, Excel and HTML outputs.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("database", type=Path, help="Path to SQLite .db file")
    parser.add_argument("--output", type=Path, default=Path("author_analysis_output"))
    parser.add_argument("--table", default="articles")
    parser.add_argument("--authors-column", default="authors_json")
    for option in ("id", "year", "title", "abstract", "keywords", "journal", "doi", "citations"):
        parser.add_argument(f"--{option}-column")
    parser.add_argument("--identity-mode", choices=["conservative", "balanced", "name-only"], default="balanced")
    parser.add_argument("--chunk-size", type=int, default=10000)
    parser.add_argument("--max-papers", type=int)
    parser.add_argument("--min-author-papers", type=int, default=1)
    parser.add_argument("--min-edge-weight", type=int, default=1)
    parser.add_argument("--network-max-authors-per-paper", type=int, default=50)
    parser.add_argument("--min-team-papers", type=int, default=2)
    parser.add_argument("--min-team-size", type=int, default=3)
    parser.add_argument("--max-team-size", type=int, default=4)
    parser.add_argument("--team-combination-max-authors", type=int, default=15)
    parser.add_argument("--louvain-resolution", type=float, default=1.0)
    parser.add_argument("--random-seed", type=int, default=42)
    parser.add_argument("--static-network-top-nodes", type=int, default=350)
    parser.add_argument("--interactive-network-top-nodes", type=int, default=3000)
    parser.add_argument("--heatmap-top-authors", type=int, default=50)
    parser.add_argument("--community-html-limit", type=int, default=10)
    parser.add_argument("--no-topic-analysis", action="store_true")
    parser.add_argument("--no-paper-authors", action="store_true")
    parser.add_argument("--no-papers", action="store_true")
    parser.add_argument("--no-svg", action="store_true")
    parser.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"], default="INFO")
    return parser


def create_config(args: argparse.Namespace) -> AnalysisConfig:
    return AnalysisConfig(
        db_path=args.database, output_dir=args.output, table_name=args.table, authors_column=args.authors_column,
        id_column=args.id_column, year_column=args.year_column, title_column=args.title_column,
        abstract_column=args.abstract_column, keywords_column=args.keywords_column,
        journal_column=args.journal_column, doi_column=args.doi_column, citations_column=args.citations_column,
        identity_mode=args.identity_mode, chunk_size=args.chunk_size, max_papers=args.max_papers,
        min_author_papers=args.min_author_papers, min_edge_weight=args.min_edge_weight,
        network_max_authors_per_paper=args.network_max_authors_per_paper,
        min_team_papers=args.min_team_papers, min_team_size=args.min_team_size,
        max_team_size=args.max_team_size, team_combination_max_authors=args.team_combination_max_authors,
        louvain_resolution=args.louvain_resolution, random_seed=args.random_seed,
        static_network_top_nodes=args.static_network_top_nodes,
        interactive_network_top_nodes=args.interactive_network_top_nodes,
        heatmap_top_authors=args.heatmap_top_authors, community_html_limit=args.community_html_limit,
        enable_topic_analysis=not args.no_topic_analysis and not args.no_papers,
        export_paper_authors=not args.no_paper_authors, export_papers=not args.no_papers,
        create_svg=not args.no_svg,
    )


def main() -> int:
    args = build_parser().parse_args()
    config = create_config(args)
    config.output_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(config.output_dir / "analysis.log", encoding="utf-8")],
    )
    logger = logging.getLogger("app")
    started = time.perf_counter()
    try:
        analyzer = BibliometricAnalyzer(config)
        data = analyzer.run()
        Exporter(config, analyzer.graph, data, analyzer.network_summary).export_all()
        Visualizer(config, analyzer.graph, data, analyzer.network_summary).create_all()
        logger.info("Analysis finished in %.2f seconds", time.perf_counter() - started)
        logger.info("Excel: %s", config.output_dir / "tables" / "analysis_report.xlsx")
        logger.info("Dashboard: %s", config.output_dir / "interactive" / "dashboard.html")
        logger.info("Gephi: %s", config.output_dir / "networks" / "coauthorship.gexf")
        return 0
    except KeyboardInterrupt:
        logger.warning("Interrupted by user")
        return 130
    except Exception:
        logger.exception("Analysis failed")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
