from __future__ import annotations

import argparse
import logging
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from author_analysis.community_analysis import (
    build_community_paper_outputs,
    export_community_html,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Create per-cluster article lists and infer each cluster's research "
            "field from an existing analysis result directory. No network "
            "centrality is recalculated."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("results_dir", type=Path, help="Existing result directory, e.g. resultsLight")
    parser.add_argument("--field-top-terms", type=int, default=20)
    parser.add_argument("--field-label-terms", type=int, default=5)
    parser.add_argument("--representative-papers", type=int, default=12)
    parser.add_argument("--core-membership-threshold", type=float, default=0.50)
    parser.add_argument("--max-features", type=int, default=20_000)
    parser.add_argument("--min-documents-for-field", type=int, default=3)
    return parser


def safe_width(series: pd.Series, name: Any) -> float:
    lengths = []
    for value in series.head(5000):
        if value is None:
            lengths.append(0)
            continue
        try:
            if bool(pd.isna(value)):
                lengths.append(0)
                continue
        except (TypeError, ValueError):
            pass
        lengths.append(min(len(str(value)), 120))
    observed = int(np.quantile(lengths, 0.95)) if lengths else len(str(name))
    return float(min(max(max(len(str(name)), observed) + 2, 11), 48))


def write_excel(path: Path, outputs: dict[str, pd.DataFrame]) -> None:
    with pd.ExcelWriter(path, engine="xlsxwriter") as writer:
        workbook = writer.book
        header = workbook.add_format({
            "bold": True,
            "font_color": "#FFFFFF",
            "bg_color": "#345B8C",
            "align": "center",
            "valign": "vcenter",
            "text_wrap": True,
        })
        percent = workbook.add_format({"num_format": "0.00%"})
        decimal = workbook.add_format({"num_format": "0.0000"})
        names = {
            "community_fields": "Cluster_Fields",
            "community_papers": "Cluster_Papers",
            "community_representative_papers": "Representative_Papers",
        }
        for key, frame in outputs.items():
            if frame is None or frame.empty:
                continue
            sheet = names[key][:31]
            frame.to_excel(writer, sheet_name=sheet, index=False)
            ws = writer.sheets[sheet]
            ws.freeze_panes(1, 1)
            ws.autofilter(0, 0, len(frame), len(frame.columns) - 1)
            ws.set_row(0, 32, header)
            for col, column in enumerate(frame.columns):
                lower = str(column).casefold()
                fmt = None
                if any(token in lower for token in ("share", "rate", "ratio")):
                    fmt = percent
                elif any(token in lower for token in ("score", "mean", "relevance")):
                    fmt = decimal
                ws.set_column(col, col, safe_width(frame[column], column), fmt)


def main() -> int:
    args = build_parser().parse_args()
    results_dir = args.results_dir.expanduser().resolve()
    tables_dir = results_dir / "tables"
    if not tables_dir.exists():
        raise FileNotFoundError(f"Tables directory not found: {tables_dir}")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )
    logger = logging.getLogger("cluster-paper-analysis")

    authors_path = tables_dir / "authors.csv"
    paper_candidates = [tables_dir / "paper_topics.csv", tables_dir / "papers.csv"]
    papers_path = next((path for path in paper_candidates if path.exists()), None)
    if not authors_path.exists():
        raise FileNotFoundError(f"Required file not found: {authors_path}")
    if papers_path is None:
        raise FileNotFoundError(
            "Neither paper_topics.csv nor papers.csv was found. The original run "
            "must not use --no-papers."
        )

    logger.info("Reading %s", authors_path)
    authors = pd.read_csv(authors_path, low_memory=False)
    logger.info("Reading %s", papers_path)
    papers = pd.read_csv(papers_path, low_memory=False)

    required_author_columns = {"author_id", "community"}
    missing = required_author_columns - set(authors.columns)
    if missing:
        raise ValueError(f"authors.csv is missing columns: {sorted(missing)}")
    if "author_ids" not in papers.columns:
        raise ValueError("Paper table is missing author_ids.")

    author_communities = (
        authors.dropna(subset=["author_id", "community"])
        .set_index("author_id")["community"]
        .astype(int)
        .to_dict()
    )
    author_names = (
        authors.set_index("author_id")["author_name"].fillna("").astype(str).to_dict()
        if "author_name" in authors.columns
        else {}
    )
    author_pagerank = (
        pd.to_numeric(authors.set_index("author_id")["pagerank"], errors="coerce")
        .fillna(0.0)
        .to_dict()
        if "pagerank" in authors.columns
        else {}
    )

    outputs = build_community_paper_outputs(
        papers,
        author_communities,
        author_names,
        author_pagerank,
        field_top_terms=args.field_top_terms,
        field_label_terms=args.field_label_terms,
        representative_papers=args.representative_papers,
        core_membership_threshold=args.core_membership_threshold,
        max_features=args.max_features,
        min_documents_for_field=args.min_documents_for_field,
    )

    cluster_dir = results_dir / "clusters"
    cluster_dir.mkdir(parents=True, exist_ok=True)
    for key, frame in outputs.items():
        if frame is not None and not frame.empty:
            frame.to_csv(tables_dir / f"{key}.csv", index=False, encoding="utf-8-sig")
            frame.to_csv(cluster_dir / f"{key}.csv", index=False, encoding="utf-8-sig")

    community_papers = outputs["community_papers"]
    for community, frame in community_papers.groupby("community", sort=True):
        frame.to_csv(
            cluster_dir / f"community_{int(community):04d}_papers.csv",
            index=False,
            encoding="utf-8-sig",
        )

    excel_path = cluster_dir / "cluster_article_catalogue.xlsx"
    write_excel(excel_path, outputs)

    communities_path = tables_dir / "communities.csv"
    if communities_path.exists() and not outputs["community_fields"].empty:
        communities = pd.read_csv(communities_path, low_memory=False)
        fields = outputs["community_fields"]
        enriched = communities.merge(fields, on="community", how="left", suffixes=("", "_field"))
        enriched.to_csv(
            cluster_dir / "communities_with_fields.csv",
            index=False,
            encoding="utf-8-sig",
        )

    interactive_dir = results_dir / "interactive"
    interactive_dir.mkdir(parents=True, exist_ok=True)
    export_community_html(
        interactive_dir,
        outputs["community_fields"],
        outputs["community_papers"],
        outputs["community_representative_papers"],
    )

    logger.info("Cluster profiles: %s", len(outputs["community_fields"]))
    logger.info("Paper-cluster relationships: %s", len(outputs["community_papers"]))
    logger.info("Excel catalogue: %s", excel_path)
    logger.info("HTML catalogue: %s", interactive_dir / "cluster_catalog.html")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
