# تحلیل جامع نویسندگان و شبکه هم‌نویسندگی

این پروژه ستون `authors_json` جدول `articles` در SQLite را تحلیل می‌کند.

## تحلیل‌ها

- پاک‌سازی JSON و گزارش رکوردهای خراب
- شناسایی نویسندگان با اولویت ORCID
- شبکه وزنی هم‌نویسندگی و کلاستر Louvain
- Degree، Weighted Degree، PageRank، Betweenness، Closeness، Eigenvector
- Participation Coefficient، Within-module Z-score، Bridging Centrality و نقش شبکه‌ای
- زوج‌های همکاری قوی، Jaccard و وابستگی همکاری
- تیم‌های تکرارشونده سه و چهار نفره
- شبکه مؤسسات و کشورها
- روند سالانه، نویسندگان تازه‌وارد، همکاری بین‌المللی و بین‌مؤسسه‌ای
- پوشش ORCID و affiliation و نویسندگان احتمالاً تکراری
- تحلیل اختیاری موضوعات با TF-IDF و MiniBatchKMeans

## خروجی‌ها

- `tables/analysis_report.xlsx`: گزارش Excel چندبرگی با داشبورد و نمودار
- CSV مستقل برای همه جدول‌ها
- `networks/coauthorship.gexf`: آماده Gephi با رنگ کلاستر، اندازه و موقعیت اولیه
- `networks/coauthorship.graphml`
- `networks/gephi_nodes.csv` و `gephi_edges.csv`
- شبکه‌های مؤسسات و کشورها در GEXF/GraphML
- `interactive/coauthorship_network.html`: شبکه تعاملی با زوم، جست‌وجو و فیلتر
- `interactive/dashboard.html`: داشبورد Plotly
- نمودارهای PNG و SVG با وضوح بالا

## نصب در ویندوز

```bat
install_windows.bat
```

یا:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## اجرا

```bat
python app.py "D:\data\articles.db" --output "D:\data\author_results"
```

نسخه خلوت‌تر و خواناتر برای دیتاست بزرگ:

```bat
python app.py articles.db ^
  --output results ^
  --min-author-papers 2 ^
  --min-edge-weight 2 ^
  --interactive-network-top-nodes 2500 ^
  --static-network-top-nodes 300
```

برای دیتابیس بسیار بزرگ و مصرف حافظه کمتر:

```bat
python app.py huge.db ^
  --output results_large ^
  --chunk-size 25000 ^
  --min-author-papers 2 ^
  --min-edge-weight 2 ^
  --no-paper-authors ^
  --no-papers ^
  --no-topic-analysis
```

## تعیین نام ستون‌ها

برنامه نام‌های رایج را خودکار پیدا می‌کند. در صورت نیاز:

```bat
python app.py articles.db ^
  --year-column publication_year ^
  --title-column title ^
  --abstract-column abstract ^
  --citations-column is_referenced_by_count
```

## روش شناسایی نویسنده

- `balanced`: ORCID؛ و در نبود آن نام + مؤسسه والد
- `conservative`: ORCID؛ و در نبود آن نام + affiliation کامل
- `name-only`: ORCID؛ و در نبود آن فقط نام؛ خطر ادغام افراد هم‌نام بیشتر است

## پیشنهاد برای Gephi

1. فایل `coauthorship.gexf` را باز کنید.
2. رنگ Node را براساس `community` قرار دهید.
3. اندازه Node را براساس `pagerank` یا `weighted_degree` تنظیم کنید.
4. ضخامت Edge را براساس `weight` قرار دهید.
5. از ForceAtlas2 استفاده کنید.
6. برای خوانایی، Edge Weight کمتر از 2 یا 3 را فیلتر کنید.

## ستون‌های مهم

- `weighted_degree`: قدرت کل همکاری‌ها
- `pagerank`: اهمیت نویسنده با توجه به اهمیت همکاران
- `betweenness`: میزان واسطه‌بودن میان گروه‌ها
- `participation_coefficient`: پراکندگی روابط فرد میان کلاسترها
- `within_module_z`: اهمیت فرد داخل کلاستر خودش
- `bridging_centrality`: توان پل‌بودن میان بخش‌های شبکه
- `jaccard_collaboration`: شدت نرمال‌شده همکاری دو نویسنده
- `source_dependency` و `target_dependency`: سهم مقالات هر نویسنده که با طرف مقابل نوشته شده است

استنتاج استاد–دانشجو یا رهبر قطعی گروه فقط از ترتیب نویسندگان معتبر نیست و باید با نویسنده مسئول، نویسنده آخر و اطلاعات شغلی تکمیل شود.
