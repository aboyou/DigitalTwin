@echo off
setlocal
cd /d "%~dp0"
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Installation completed.
echo Run: .venv\Scripts\python app.py "C:\path\to\articles.db" --output results
pause
