"""Author collaboration and bibliometric network analysis package."""

__version__ = "1.0.0"
