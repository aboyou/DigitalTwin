from __future__ import annotations

import hashlib
import html
import json
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

import pycountry


_WS_RE = re.compile(r"\s+")
_NON_NAME_RE = re.compile(r"[^\w\s'\-À-ÖØ-öø-ÿĀ-žΑ-ωА-я\u0600-\u06ff]", re.UNICODE)
_ORCID_RE = re.compile(r"^(?:https?://orcid\.org/)?(\d{4}-\d{4}-\d{4}-[\dXx]{4})$")
_DIGIT_ADDRESS_RE = re.compile(r"\b\d{1,6}(?:[-/]\d{1,6})?\b")
_POSTAL_RE = re.compile(r"\b[A-Z]?\d{4,6}[A-Z]?\b", re.IGNORECASE)

ORG_MARKERS = (
    "university", "universität", "universite", "université", "universidad",
    "institute", "institut", "academy", "college", "hospital", "laboratory",
    "laboratoire", "lab", "centre", "center", "school", "survey", "agency",
    "corporation", "company", "group", "research council", "cnrs", "geus",
    "polytechnic", "department", "faculty", "observatory", "foundation",
)

COUNTRY_ALIASES = {
    "usa": "United States",
    "u.s.a.": "United States",
    "u.s.": "United States",
    "united states of america": "United States",
    "uk": "United Kingdom",
    "u.k.": "United Kingdom",
    "england": "United Kingdom",
    "scotland": "United Kingdom",
    "wales": "United Kingdom",
    "south korea": "Korea, Republic of",
    "republic of korea": "Korea, Republic of",
    "north korea": "Korea, Democratic People's Republic of",
    "russia": "Russian Federation",
    "iran": "Iran, Islamic Republic of",
    "iran, islamic republic of": "Iran, Islamic Republic of",
    "vietnam": "Viet Nam",
    "taiwan": "Taiwan, Province of China",
    "hong kong": "Hong Kong",
    "macao": "Macao",
    "czech republic": "Czechia",
    "bolivia": "Bolivia, Plurinational State of",
    "tanzania": "Tanzania, United Republic of",
    "venezuela": "Venezuela, Bolivarian Republic of",
    "moldova": "Moldova, Republic of",
    "laos": "Lao People's Democratic Republic",
    "syria": "Syrian Arab Republic",
}

DEPARTMENT_PREFIXES = (
    "department of ", "dept. of ", "dept of ", "school of ", "faculty of ",
    "college of ", "laboratory of ", "lab of ", "centre for ", "center for ",
    "division of ", "institute of ",
)


def compact_ws(value: Any) -> str:
    if value is None:
        return ""
    return _WS_RE.sub(" ", str(value)).strip()


def normalize_unicode(value: Any) -> str:
    return unicodedata.normalize("NFKC", compact_ws(value))


def normalize_name(value: Any) -> str:
    text = normalize_unicode(value)
    text = _NON_NAME_RE.sub(" ", text)
    return _WS_RE.sub(" ", text).strip().casefold()


def display_name(given: Any, family: Any) -> str:
    return compact_ws(f"{compact_ws(given)} {compact_ws(family)}")


def stable_hash(value: str, length: int = 20) -> str:
    return hashlib.sha1(value.encode("utf-8", errors="ignore")).hexdigest()[:length]


def normalize_orcid(value: Any) -> Optional[str]:
    if value is None:
        return None
    match = _ORCID_RE.match(compact_ws(value))
    if not match:
        return None
    orcid = match.group(1).upper()
    return orcid if validate_orcid_checksum(orcid) else None


def validate_orcid_checksum(orcid: str) -> bool:
    digits = orcid.replace("-", "")
    if len(digits) != 16:
        return False
    total = 0
    for char in digits[:-1]:
        if not char.isdigit():
            return False
        total = (total + int(char)) * 2
    result = (12 - total % 11) % 11
    check = "X" if result == 10 else str(result)
    return check == digits[-1].upper()


def parse_json_array(value: Any) -> tuple[list[dict[str, Any]], Optional[str]]:
    if value is None:
        return [], None
    if isinstance(value, list):
        data = value
    elif isinstance(value, dict):
        data = [value]
    else:
        text = compact_ws(value)
        if not text or text.lower() in {"null", "none", "nan", "[]"}:
            return [], None
        try:
            data = json.loads(text)
        except Exception as exc:
            return [], f"{type(exc).__name__}: {exc}"

    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        return [], f"Expected list/dict, got {type(data).__name__}"
    return [item for item in data if isinstance(item, dict)], None


def affiliations_to_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = compact_ws(value)
        return [text] if text else []
    if isinstance(value, dict):
        candidates = [
            value.get("name"), value.get("institution"), value.get("affiliation"),
            value.get("value"),
        ]
        return [compact_ws(x) for x in candidates if compact_ws(x)]
    if isinstance(value, list):
        output: list[str] = []
        for item in value:
            output.extend(affiliations_to_list(item))
        return list(dict.fromkeys(output))
    return [compact_ws(value)] if compact_ws(value) else []


def normalize_affiliation(value: Any) -> str:
    text = normalize_unicode(value)
    text = text.replace("؛", ",").replace("،", ",")
    text = re.sub(r"\s*,\s*", ", ", text)
    return _WS_RE.sub(" ", text).strip(" ,;")


def country_from_affiliation(affiliation: str) -> Optional[str]:
    text = normalize_affiliation(affiliation)
    if not text:
        return None
    folded = text.casefold()

    for alias, canonical in sorted(
        COUNTRY_ALIASES.items(), key=lambda item: len(item[0]), reverse=True
    ):
        if re.search(rf"(?<!\w){re.escape(alias.casefold())}(?!\w)", folded):
            return canonical

    candidates: list[tuple[int, str]] = []
    for country in pycountry.countries:
        names = {
            getattr(country, "name", ""),
            getattr(country, "official_name", ""),
            getattr(country, "common_name", ""),
            getattr(country, "alpha_2", ""),
            getattr(country, "alpha_3", ""),
        }
        for name in filter(None, names):
            name_folded = name.casefold()
            if len(name_folded) <= 3 and name_folded not in {"usa", "uk"}:
                continue
            pos = folded.rfind(name_folded)
            if pos >= 0:
                candidates.append((pos, country.name))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def parent_institution(affiliation: str) -> str:
    text = normalize_affiliation(affiliation)
    if not text:
        return ""

    segments = [compact_ws(x) for x in re.split(r"[,;|]", text) if compact_ws(x)]
    marker_segments = [
        seg for seg in segments
        if any(marker in seg.casefold() for marker in ORG_MARKERS)
    ]
    if marker_segments:
        for seg in marker_segments:
            if not seg.casefold().startswith(DEPARTMENT_PREFIXES):
                return _clean_institution_segment(seg)
        if len(marker_segments) > 1:
            return _clean_institution_segment(marker_segments[-1])

    patterns = [
        r"([A-ZÀ-ÖØ-Þ0-9][\wÀ-ÖØ-öø-ÿ&'.()\-]*(?:\s+[A-ZÀ-ÖØ-Þ0-9][\wÀ-ÖØ-öø-ÿ&'.()\-]*){0,7}\s+(?:University|Universität|Université|Universidad|Institute|Institut|Academy|College|Hospital|Polytechnic))",
        r"((?:Geological|National|Federal|Royal|Danish|Chinese|Korean|French|German|Italian|Spanish|Indian|Australian|Canadian|Japanese|Swedish|Norwegian|Finnish|Dutch|Swiss|Austrian|Belgian|Brazilian|Iranian|Turkish|Russian|British|American)\s+(?:Survey|Agency|Laboratory|Centre|Center|Council|Foundation)(?:\s+of\s+[A-Z][\w\-]+){0,5})",
    ]
    for pattern in patterns:
        matches = re.findall(pattern, text, flags=re.IGNORECASE)
        if matches:
            return _clean_institution_segment(matches[-1])

    cleaned = _DIGIT_ADDRESS_RE.sub(" ", text)
    cleaned = _POSTAL_RE.sub(" ", cleaned)
    country = country_from_affiliation(cleaned)
    if country:
        cleaned = re.sub(re.escape(country), " ", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(
        r"\b(street|st\.|road|rd\.|avenue|ave\.|boulevard|blvd\.|postal|postcode|zip)\b.*$",
        " ", cleaned, flags=re.IGNORECASE,
    )
    cleaned = compact_ws(cleaned.strip(" ,;-"))
    return cleaned[:220] if cleaned else text[:220]


def _clean_institution_segment(segment: str) -> str:
    segment = _DIGIT_ADDRESS_RE.sub(" ", segment)
    segment = _POSTAL_RE.sub(" ", segment)
    return compact_ws(segment.strip(" ,;-"))[:220]


@dataclass(slots=True)
class ResolvedAuthor:
    author_id: str
    display_name: str
    given: str
    family: str
    normalized_name: str
    orcid: Optional[str]
    sequence: str
    affiliations: list[str]
    institutions: list[str]
    countries: list[str]
    raw: dict[str, Any] = field(default_factory=dict)


class AuthorResolver:
    def __init__(self, identity_mode: str = "balanced") -> None:
        self.identity_mode = identity_mode

    def resolve(self, raw: dict[str, Any]) -> Optional[ResolvedAuthor]:
        given = compact_ws(raw.get("given") or raw.get("first") or raw.get("given_name"))
        family = compact_ws(raw.get("family") or raw.get("last") or raw.get("family_name"))
        literal = compact_ws(raw.get("name") or raw.get("literal"))
        full = display_name(given, family) or literal
        normalized = normalize_name(full)
        if not normalized:
            return None

        orcid = normalize_orcid(raw.get("orcid") or raw.get("ORCID"))
        sequence = compact_ws(raw.get("sequence") or raw.get("position")).casefold()
        if sequence not in {"first", "additional"}:
            sequence = sequence or "unknown"

        affiliations = affiliations_to_list(
            raw.get("affiliations") if "affiliations" in raw else raw.get("affiliation")
        )
        affiliations = [normalize_affiliation(x) for x in affiliations if normalize_affiliation(x)]
        institutions = list(dict.fromkeys(
            x for x in (parent_institution(a) for a in affiliations) if x
        ))
        countries = list(dict.fromkeys(
            x for x in (country_from_affiliation(a) for a in affiliations) if x
        ))

        if orcid:
            author_id = f"orcid:{orcid}"
        elif self.identity_mode == "name-only":
            author_id = f"name:{stable_hash(normalized)}"
        elif self.identity_mode == "conservative":
            context = affiliations[0].casefold() if affiliations else "no-affiliation"
            author_id = f"local:{stable_hash(normalized + '|' + context)}"
        else:
            context = institutions[0].casefold() if institutions else "no-institution"
            author_id = f"local:{stable_hash(normalized + '|' + context)}"

        return ResolvedAuthor(
            author_id=author_id,
            display_name=full,
            given=given,
            family=family,
            normalized_name=normalized,
            orcid=orcid,
            sequence=sequence,
            affiliations=affiliations,
            institutions=institutions,
            countries=countries,
            raw=raw,
        )


def safe_html(value: Any) -> str:
    return html.escape(compact_ws(value), quote=True)


def safe_scalar(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple, set)):
        return "; ".join(compact_ws(x) for x in value)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return compact_ws(value)


def unique_preserve(values: Iterable[str]) -> list[str]:
    return list(dict.fromkeys(x for x in values if x))
