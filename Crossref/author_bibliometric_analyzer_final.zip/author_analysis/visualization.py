from __future__ import annotations

import logging
import math
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
from pyvis.network import Network

from .config import AnalysisConfig
from .normalization import safe_html

LOGGER = logging.getLogger(__name__)

PALETTE = [
    "#4C78A8", "#F58518", "#E45756", "#72B7B2", "#54A24B",
    "#EECA3B", "#B279A2", "#FF9DA6", "#9D755D", "#BAB0AC",
    "#5B8FF9", "#61DDAA", "#65789B", "#F6BD16", "#7262FD",
    "#78D3F8", "#9661BC", "#F6903D", "#008685", "#F08BB4",
]


def community_color(community: int) -> str:
    return PALETTE[(max(int(community), 1) - 1) % len(PALETTE)]


def hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    value = hex_color.lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))


class Visualizer:
    def __init__(
        self,
        config: AnalysisConfig,
        graph: nx.Graph,
        data: dict[str, pd.DataFrame],
        network_summary: dict[str, Any],
    ) -> None:
        self.config = config
        self.graph = graph
        self.data = data
        self.network_summary = network_summary
        self.fig_dir = config.output_dir / "figures"
        self.html_dir = config.output_dir / "interactive"
        self.fig_dir.mkdir(parents=True, exist_ok=True)
        self.html_dir.mkdir(parents=True, exist_ok=True)

    def create_all(self) -> None:
        self._set_plot_style()
        self.create_static_charts()
        self.create_static_network()
        self.create_interactive_network()
        self.create_community_networks()
        self.create_dashboard()

    @staticmethod
    def _set_plot_style() -> None:
        plt.rcParams.update({
            "figure.facecolor": "#F7F8FA",
            "axes.facecolor": "#FFFFFF",
            "axes.edgecolor": "#D8DDE6",
            "axes.labelcolor": "#303744",
            "text.color": "#202632",
            "xtick.color": "#4C5563",
            "ytick.color": "#4C5563",
            "grid.color": "#E7EAF0",
            "grid.linewidth": 0.8,
            "font.size": 10,
            "axes.titleweight": "bold",
            "axes.titlesize": 15,
        })

    def _save(self, fig: plt.Figure, filename: str) -> None:
        fig.tight_layout()
        fig.savefig(self.fig_dir / f"{filename}.png", dpi=self.config.image_dpi, bbox_inches="tight")
        if self.config.create_svg:
            fig.savefig(self.fig_dir / f"{filename}.svg", bbox_inches="tight")
        plt.close(fig)

    @staticmethod
    def _top_bar(df: pd.DataFrame, label: str, value: str, title: str, n: int = 20):
        top = df.nlargest(n, value).sort_values(value)
        fig, ax = plt.subplots(figsize=(12, 8))
        ax.barh(top[label].astype(str), top[value])
        ax.set_title(title)
        ax.set_xlabel(value.replace("_", " ").title())
        ax.grid(axis="x")
        return fig

    def create_static_charts(self) -> None:
        authors = self.data.get("authors", pd.DataFrame())
        yearly = self.data.get("yearly_trends", pd.DataFrame())
        communities = self.data.get("communities", pd.DataFrame())
        institutions = self.data.get("institutions", pd.DataFrame())
        countries = self.data.get("countries", pd.DataFrame())
        collaborations = self.data.get("collaborations", pd.DataFrame())
        papers = self.data.get("papers", pd.DataFrame())

        if not authors.empty:
            self._save(self._top_bar(authors, "author_name", "papers", "Top authors by number of papers"), "01_top_authors_by_papers")
            self._save(self._top_bar(authors, "author_name", "pagerank", "Most central authors by PageRank"), "02_top_authors_by_pagerank")

            fig, ax = plt.subplots(figsize=(10, 7))
            sizes = 30 + 900 * self._scale(authors["betweenness"])
            ax.scatter(
                authors["papers"], authors["weighted_degree"], s=sizes,
                c=authors["community"], alpha=0.70, cmap="tab20",
                edgecolors="white", linewidths=0.4,
            )
            ax.set_title("Productivity, collaboration strength and brokerage")
            ax.set_xlabel("Papers")
            ax.set_ylabel("Weighted degree")
            ax.grid(True)
            self._save(fig, "03_productivity_vs_collaboration")

        if not yearly.empty:
            fig, ax = plt.subplots(figsize=(12, 6))
            for column, label in (("papers", "Papers"), ("active_authors", "Active authors"), ("new_authors", "New authors")):
                ax.plot(yearly["publication_year"], yearly[column], marker="o", label=label)
            ax.set_title("Evolution of the research community")
            ax.set_xlabel("Publication year")
            ax.set_ylabel("Count")
            ax.legend(frameon=False, ncol=3)
            ax.grid(True)
            self._save(fig, "04_yearly_research_evolution")

            fig, ax = plt.subplots(figsize=(12, 6))
            ax.plot(yearly["publication_year"], yearly["international_collaboration_rate"] * 100, marker="o", label="International")
            ax.plot(yearly["publication_year"], yearly["cross_institution_rate"] * 100, marker="o", label="Cross-institution")
            ax.set_title("Collaboration openness over time")
            ax.set_xlabel("Publication year")
            ax.set_ylabel("Share of papers (%)")
            ax.set_ylim(bottom=0)
            ax.legend(frameon=False)
            ax.grid(True)
            self._save(fig, "05_collaboration_rates_over_time")

        if not communities.empty:
            temp = communities.copy()
            temp["community_label"] = temp["community"].astype(str)
            self._save(self._top_bar(temp, "community_label", "author_count", "Largest author communities"), "06_community_sizes")
        if not institutions.empty:
            self._save(self._top_bar(institutions, "institution", "papers", "Most active institutions"), "07_top_institutions")
        if not countries.empty:
            self._save(self._top_bar(countries, "country", "papers", "Most active countries"), "08_top_countries")

        if not collaborations.empty:
            top = collaborations.nlargest(25, "shared_papers").copy()
            top["pair"] = top["source_name"] + " ↔ " + top["target_name"]
            top = top.sort_values("shared_papers")
            fig, ax = plt.subplots(figsize=(13, 10))
            ax.barh(top["pair"], top["shared_papers"])
            ax.set_title("Strongest repeated co-author relationships")
            ax.set_xlabel("Shared papers")
            ax.grid(axis="x")
            self._save(fig, "09_strongest_collaborations")

        if not papers.empty and "team_size" in papers.columns:
            clipped = papers["team_size"].clip(upper=max(1, papers["team_size"].quantile(0.99)))
            fig, ax = plt.subplots(figsize=(10, 6))
            bins = min(30, max(5, int(clipped.max())))
            ax.hist(clipped.dropna(), bins=bins, edgecolor="white")
            ax.set_title("Distribution of paper team sizes")
            ax.set_xlabel("Authors per paper")
            ax.set_ylabel("Papers")
            ax.grid(axis="y")
            self._save(fig, "10_team_size_distribution")

        self.create_coauthor_heatmap()

    def create_coauthor_heatmap(self) -> None:
        authors = self.data.get("authors", pd.DataFrame())
        collaborations = self.data.get("collaborations", pd.DataFrame())
        if authors.empty or collaborations.empty:
            return
        top = authors.nlargest(self.config.heatmap_top_authors, "weighted_degree")
        ids = list(top["author_id"])
        names = top.set_index("author_id")["author_name"].to_dict()
        index = {author_id: i for i, author_id in enumerate(ids)}
        matrix = np.zeros((len(ids), len(ids)), dtype=float)
        for edge in collaborations.itertuples():
            if edge.source in index and edge.target in index:
                i, j = index[edge.source], index[edge.target]
                matrix[i, j] = edge.shared_papers
                matrix[j, i] = edge.shared_papers
        fig, ax = plt.subplots(figsize=(14, 12))
        image = ax.imshow(matrix, cmap="viridis", aspect="auto")
        labels = [names[author_id] for author_id in ids]
        ax.set_xticks(range(len(ids)))
        ax.set_yticks(range(len(ids)))
        ax.set_xticklabels(labels, rotation=90, fontsize=6)
        ax.set_yticklabels(labels, fontsize=6)
        ax.set_title("Co-authorship intensity among top network authors")
        fig.colorbar(image, ax=ax, fraction=0.03, pad=0.02, label="Shared papers")
        self._save(fig, "11_coauthor_heatmap")

    def create_static_network(self) -> None:
        if self.graph.number_of_nodes() == 0:
            return
        nodes = sorted(
            self.graph.nodes,
            key=lambda node: (self.graph.nodes[node].get("pagerank", 0), self.graph.nodes[node].get("papers", 0)),
            reverse=True,
        )[:self.config.static_network_top_nodes]
        subgraph = self.graph.subgraph(nodes).copy()
        if subgraph.number_of_edges() == 0:
            return
        position = nx.spring_layout(
            subgraph, seed=self.config.random_seed, weight="weight",
            k=max(0.15, 1.7 / math.sqrt(max(subgraph.number_of_nodes(), 1))), iterations=180,
        )
        node_sizes = [60 + 2400 * math.sqrt(max(subgraph.nodes[n].get("pagerank", 0), 0)) for n in subgraph]
        node_colors = [community_color(subgraph.nodes[n].get("community", 1)) for n in subgraph]
        edge_widths = [0.25 + 1.25 * math.log1p(a.get("weight", 1)) for _, _, a in subgraph.edges(data=True)]
        fig, ax = plt.subplots(figsize=(18, 14))
        nx.draw_networkx_edges(subgraph, position, ax=ax, width=edge_widths, alpha=0.20, edge_color="#687386")
        nx.draw_networkx_nodes(subgraph, position, ax=ax, node_size=node_sizes, node_color=node_colors, alpha=0.90, linewidths=0.8, edgecolors="white")
        label_nodes = sorted(subgraph.nodes, key=lambda n: subgraph.nodes[n].get("pagerank", 0), reverse=True)[:self.config.labels_in_static_network]
        labels = {n: subgraph.nodes[n].get("label", n) for n in label_nodes}
        nx.draw_networkx_labels(subgraph, position, labels=labels, font_size=8, font_weight="bold", ax=ax)
        ax.set_title("Co-authorship network\nNode size: PageRank | Color: community | Edge width: shared papers", fontsize=18)
        ax.axis("off")
        self._save(fig, "12_coauthorship_network")

    def create_interactive_network(self) -> None:
        if self.graph.number_of_nodes() == 0:
            return
        nodes = sorted(
            self.graph.nodes,
            key=lambda n: (self.graph.nodes[n].get("pagerank", 0), self.graph.nodes[n].get("weighted_degree", 0)),
            reverse=True,
        )[:self.config.interactive_network_top_nodes]
        self._write_pyvis(self.graph.subgraph(nodes).copy(), self.html_dir / "coauthorship_network.html")

    def create_community_networks(self) -> None:
        communities: dict[int, list[str]] = {}
        for node, attrs in self.graph.nodes(data=True):
            communities.setdefault(int(attrs.get("community", 0)), []).append(node)
        largest = sorted(communities.items(), key=lambda item: len(item[1]), reverse=True)[:self.config.community_html_limit]
        target_dir = self.html_dir / "communities"
        target_dir.mkdir(parents=True, exist_ok=True)
        for community, nodes in largest:
            subgraph = self.graph.subgraph(nodes).copy()
            if len(nodes) >= 2 and subgraph.number_of_edges() > 0:
                self._write_pyvis(subgraph, target_dir / f"community_{community}.html")

    def _write_pyvis(self, graph: nx.Graph, output_path: Path) -> None:
        network = Network(
            height="900px", width="100%", bgcolor="#0E1420", font_color="#F5F7FA",
            notebook=False, directed=False, select_menu=True, filter_menu=True, cdn_resources="in_line",
        )
        for node, attrs in graph.nodes(data=True):
            community = int(attrs.get("community", 1))
            title = (
                f"<b>{safe_html(attrs.get('label', node))}</b><br>"
                f"Papers: {attrs.get('papers', 0)}<br>Community: {community}<br>"
                f"Role: {safe_html(attrs.get('network_role', ''))}<br>"
                f"Degree: {attrs.get('degree', 0)}<br>Weighted degree: {attrs.get('weighted_degree', 0):.2f}<br>"
                f"PageRank: {attrs.get('pagerank', 0):.6f}<br>Betweenness: {attrs.get('betweenness', 0):.6f}<br>"
                f"Institution: {safe_html(attrs.get('primary_institution', ''))}<br>"
                f"Country: {safe_html(attrs.get('primary_country', ''))}<br>"
                f"Years: {safe_html(attrs.get('first_year', ''))}–{safe_html(attrs.get('last_year', ''))}"
            )
            size = 10 + 90 * math.sqrt(max(float(attrs.get("pagerank", 0)), 0))
            network.add_node(
                node, label=str(attrs.get("label", node)), title=title, group=community,
                color=community_color(community), size=size,
                value=max(float(attrs.get("weighted_degree", 1)), 1), shape="dot", borderWidth=1,
            )
        for source, target, attrs in graph.edges(data=True):
            weight = float(attrs.get("weight", 1))
            network.add_edge(
                source, target, value=weight, width=0.5 + math.log1p(weight),
                title=f"Shared papers: {int(weight)}",
                color={"color": "#8B96A8", "opacity": 0.28},
            )
        network.set_options('''
        {
          "interaction": {"hover": true, "tooltipDelay": 100, "hideEdgesOnDrag": true, "navigationButtons": true, "keyboard": true},
          "nodes": {"font": {"size": 16, "face": "Arial"}, "scaling": {"min": 8, "max": 60}},
          "edges": {"smooth": {"enabled": true, "type": "continuous"}, "scaling": {"min": 0.5, "max": 8}},
          "physics": {
            "enabled": true, "solver": "forceAtlas2Based",
            "forceAtlas2Based": {"gravitationalConstant": -55, "centralGravity": 0.008, "springLength": 110, "springConstant": 0.05, "damping": 0.45, "avoidOverlap": 0.35},
            "stabilization": {"enabled": true, "iterations": 800, "updateInterval": 25}
          }
        }
        ''')
        network.save_graph(str(output_path))

    def create_dashboard(self) -> None:
        fragments: list[str] = []
        authors = self.data.get("authors", pd.DataFrame())
        yearly = self.data.get("yearly_trends", pd.DataFrame())
        communities = self.data.get("communities", pd.DataFrame())
        institutions = self.data.get("institutions", pd.DataFrame())
        countries = self.data.get("countries", pd.DataFrame())
        recurring = self.data.get("recurring_teams", pd.DataFrame())

        include_js = "cdn"
        if not yearly.empty:
            fig = go.Figure()
            for column, label in (("papers", "Papers"), ("active_authors", "Active authors"), ("new_authors", "New authors")):
                fig.add_trace(go.Scatter(x=yearly["publication_year"], y=yearly[column], mode="lines+markers", name=label))
            fig.update_layout(title="Research community evolution", template="plotly_white")
            fragments.append(pio.to_html(fig, full_html=False, include_plotlyjs=include_js))
            include_js = False
        if not authors.empty:
            top = authors.nlargest(25, "pagerank").sort_values("pagerank")
            fig = px.bar(top, x="pagerank", y="author_name", orientation="h", hover_data=["papers", "weighted_degree", "betweenness", "community", "primary_institution"], title="Most central authors")
            fig.update_layout(template="plotly_white", height=720)
            fragments.append(pio.to_html(fig, full_html=False, include_plotlyjs=include_js)); include_js = False
            fig = px.scatter(authors, x="papers", y="weighted_degree", size="pagerank", color="community", hover_name="author_name", hover_data=["betweenness", "participation_coefficient", "network_role", "primary_institution", "primary_country"], title="Author landscape: productivity and collaboration")
            fig.update_layout(template="plotly_white", height=650)
            fragments.append(pio.to_html(fig, full_html=False, include_plotlyjs=include_js)); include_js = False
        if not communities.empty:
            top = communities.nlargest(25, "author_count")
            fig = px.bar(top, x="community", y="author_count", hover_data=["top_authors", "top_institutions", "top_countries", "external_share"], title="Largest research communities")
            fig.update_layout(template="plotly_white")
            fragments.append(pio.to_html(fig, full_html=False, include_plotlyjs=include_js)); include_js = False
        if not institutions.empty:
            top = institutions.nlargest(25, "papers").sort_values("papers")
            fig = px.bar(top, x="papers", y="institution", orientation="h", hover_data=["authors", "first_year", "last_year", "activity_slope"], title="Top institutions")
            fig.update_layout(template="plotly_white", height=760)
            fragments.append(pio.to_html(fig, full_html=False, include_plotlyjs=include_js)); include_js = False
        if not countries.empty:
            top = countries.nlargest(20, "papers")
            fig = px.pie(top, names="country", values="papers", hole=0.45, title="Country contribution among the top countries")
            fig.update_layout(template="plotly_white")
            fragments.append(pio.to_html(fig, full_html=False, include_plotlyjs=include_js)); include_js = False
        if not recurring.empty:
            top = recurring.nlargest(30, "paper_count").copy()
            top["team"] = top["author_names"].str.slice(0, 140)
            fig = px.bar(top.sort_values("paper_count"), x="paper_count", y="team", orientation="h", hover_data=["team_size", "minimum_member_dependency"], title="Most persistent author teams")
            fig.update_layout(template="plotly_white", height=900)
            fragments.append(pio.to_html(fig, full_html=False, include_plotlyjs=include_js)); include_js = False

        kpis = {
            "Authors": self.network_summary.get("nodes", 0),
            "Edges": self.network_summary.get("edges", 0),
            "Communities": self.network_summary.get("communities", 0),
            "Density": f"{self.network_summary.get('density', 0):.5f}",
            "Giant component": f"{100 * self.network_summary.get('giant_component_ratio', 0):.1f}%",
            "Modularity": f"{self.network_summary.get('modularity', 0):.3f}",
        }
        cards = "".join(f'<div class="kpi"><span>{safe_html(label)}</span><strong>{safe_html(value)}</strong></div>' for label, value in kpis.items())
        body = "".join(f'<section class="panel">{fragment}</section>' for fragment in fragments)
        html = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Author Network Analysis Dashboard</title>
<style>
body{{margin:0;background:#F4F6F9;color:#202632;font-family:Arial,sans-serif}}header{{background:linear-gradient(135deg,#111827,#253858);color:#fff;padding:34px 5vw}}header h1{{margin:0 0 8px;font-size:30px}}header p{{margin:0;opacity:.82}}main{{max-width:1500px;margin:auto;padding:24px}}.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:22px}}.kpi{{background:#fff;border:1px solid #E2E7EF;border-radius:14px;padding:18px;box-shadow:0 5px 18px rgba(24,39,75,.05)}}.kpi span{{display:block;color:#6A7380;font-size:13px;margin-bottom:9px}}.kpi strong{{font-size:25px}}.panel{{background:#fff;border:1px solid #E2E7EF;border-radius:16px;margin:18px 0;padding:12px;box-shadow:0 5px 18px rgba(24,39,75,.05)}}.links{{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0}}.links a{{background:#253858;color:#fff;text-decoration:none;padding:10px 14px;border-radius:9px}}
</style></head><body><header><h1>Author collaboration and research-flow analysis</h1><p>Interactive summary of productivity, communities, institutions and collaboration structure.</p></header><main><div class="kpis">{cards}</div><div class="links"><a href="coauthorship_network.html">Open interactive co-authorship network</a><a href="../tables/analysis_report.xlsx">Open Excel report</a><a href="../networks/coauthorship.gexf">Open GEXF for Gephi</a></div>{body}</main></body></html>'''
        (self.html_dir / "dashboard.html").write_text(html, encoding="utf-8")

    @staticmethod
    def _scale(series: pd.Series) -> np.ndarray:
        values = pd.to_numeric(series, errors="coerce").fillna(0).to_numpy(dtype=float)
        if values.size == 0 or np.nanmax(values) == np.nanmin(values):
            return np.ones_like(values) * 0.25
        return (values - np.nanmin(values)) / (np.nanmax(values) - np.nanmin(values))
