from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass(slots=True)
class AnalysisConfig:
    db_path: Path
    output_dir: Path

    table_name: str = "articles"
    authors_column: str = "authors_json"

    id_column: Optional[str] = None
    year_column: Optional[str] = None
    title_column: Optional[str] = None
    abstract_column: Optional[str] = None
    keywords_column: Optional[str] = None
    journal_column: Optional[str] = None
    doi_column: Optional[str] = None
    citations_column: Optional[str] = None

    identity_mode: str = "balanced"
    chunk_size: int = 10_000
    max_papers: Optional[int] = None

    min_author_papers: int = 1
    min_edge_weight: int = 1
    network_max_authors_per_paper: int = 50

    min_team_papers: int = 2
    min_team_size: int = 3
    max_team_size: int = 4
    team_combination_max_authors: int = 15
    max_team_combinations_per_paper: int = 5_000

    louvain_resolution: float = 1.0
    random_seed: int = 42

    exact_betweenness_max_nodes: int = 2_000
    approximate_betweenness_samples: int = 500
    closeness_max_nodes: int = 4_000
    eigenvector_max_nodes: int = 20_000

    static_network_top_nodes: int = 350
    interactive_network_top_nodes: int = 3_000
    labels_in_static_network: int = 40
    heatmap_top_authors: int = 50
    community_html_limit: int = 10

    enable_topic_analysis: bool = True
    topic_min_documents: int = 30
    topic_max_clusters: int = 20
    topic_max_features: int = 10_000
    topic_top_terms: int = 15

    export_paper_authors: bool = True
    export_papers: bool = True
    excel_max_rows_per_sheet: int = 900_000

    image_dpi: int = 220
    create_svg: bool = True

    detected_columns: dict[str, Optional[str]] = field(default_factory=dict)

    def validate(self) -> None:
        self.db_path = Path(self.db_path).expanduser().resolve()
        self.output_dir = Path(self.output_dir).expanduser().resolve()

        if not self.db_path.exists():
            raise FileNotFoundError(f"Database file not found: {self.db_path}")

        if self.identity_mode not in {"conservative", "balanced", "name-only"}:
            raise ValueError(
                "identity_mode must be one of: conservative, balanced, name-only"
            )

        if self.chunk_size < 1:
            raise ValueError("chunk_size must be positive.")

        if self.min_author_papers < 1:
            raise ValueError("min_author_papers must be at least 1.")

        if self.min_edge_weight < 1:
            raise ValueError("min_edge_weight must be at least 1.")

        if self.min_team_size < 2:
            raise ValueError("min_team_size must be at least 2.")

        if self.max_team_size < self.min_team_size:
            raise ValueError("max_team_size must be >= min_team_size.")

        self.output_dir.mkdir(parents=True, exist_ok=True)
