from __future__ import annotations

import json
import logging
import math
from pathlib import Path
from typing import Any

import networkx as nx
import numpy as np
import pandas as pd

from .config import AnalysisConfig
from .normalization import safe_scalar
from .visualization import community_color, hex_to_rgb

LOGGER = logging.getLogger(__name__)

SHEET_NAMES = {
    "summary": "Summary", "authors": "Authors", "collaborations": "Collaborations",
    "communities": "Communities", "recurring_teams": "Recurring_Teams",
    "exact_teams": "Exact_Teams", "institutions": "Institutions",
    "institution_collaborations": "Institution_Links", "countries": "Countries",
    "country_collaborations": "Country_Links", "yearly_trends": "Yearly_Trends",
    "papers": "Papers", "paper_authors": "Paper_Authors", "data_quality": "Data_Quality",
    "parse_errors": "Parse_Errors", "possible_duplicate_authors": "Possible_Duplicates",
    "topics": "Topics", "paper_topics": "Paper_Topics", "community_topic_matrix": "Community_Topics",
}


class Exporter:
    def __init__(self, config: AnalysisConfig, graph: nx.Graph, data: dict[str, pd.DataFrame], network_summary: dict[str, Any]) -> None:
        self.config = config
        self.graph = graph
        self.data = data
        self.network_summary = network_summary
        self.tables_dir = config.output_dir / "tables"
        self.network_dir = config.output_dir / "networks"
        self.tables_dir.mkdir(parents=True, exist_ok=True)
        self.network_dir.mkdir(parents=True, exist_ok=True)

    def export_all(self) -> None:
        self.export_csvs()
        self.export_excel()
        self.export_network_files()
        self.export_manifest()

    def export_csvs(self) -> None:
        for key, dataframe in self.data.items():
            if dataframe is not None and not dataframe.empty:
                dataframe.to_csv(self.tables_dir / f"{key}.csv", index=False, encoding="utf-8-sig")

    def export_excel(self) -> None:
        output = self.tables_dir / "analysis_report.xlsx"
        with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
            workbook = writer.book
            title_format = workbook.add_format({"bold": True, "font_size": 18, "font_color": "#FFFFFF", "bg_color": "#1F3556", "align": "left", "valign": "vcenter"})
            header_format = workbook.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": "#345B8C", "align": "center", "valign": "vcenter", "text_wrap": True})
            percent_format = workbook.add_format({"num_format": "0.00%"})
            decimal_format = workbook.add_format({"num_format": "0.0000"})
            integer_format = workbook.add_format({"num_format": "0"})
            note_format = workbook.add_format({"font_color": "#566274", "italic": True, "text_wrap": True})

            dashboard = workbook.add_worksheet("Dashboard")
            writer.sheets["Dashboard"] = dashboard
            dashboard.set_tab_color("#1F3556")
            dashboard.merge_range("A1:H2", "Author Collaboration Analysis", title_format)
            dashboard.write("A4", "Author, collaboration, community, institution, country, topic and data-quality outputs.", note_format)
            dashboard.set_column("A:A", 28)
            dashboard.set_column("B:B", 18)
            dashboard.set_column("C:H", 14)

            metrics = [
                ("Authors in network", self.network_summary.get("nodes", 0)),
                ("Collaboration edges", self.network_summary.get("edges", 0)),
                ("Communities", self.network_summary.get("communities", 0)),
                ("Network density", self.network_summary.get("density", 0)),
                ("Giant component ratio", self.network_summary.get("giant_component_ratio", 0)),
                ("Modularity", self.network_summary.get("modularity", 0)),
                ("Connected components", self.network_summary.get("components", 0)),
                ("Average clustering", self.network_summary.get("average_clustering", 0)),
            ]
            for row, (label, value) in enumerate(metrics, start=5):
                dashboard.write(row, 0, label, header_format)
                if "ratio" in label.casefold():
                    dashboard.write(row, 1, value, percent_format)
                elif isinstance(value, float) and not float(value).is_integer():
                    dashboard.write(row, 1, value, decimal_format)
                else:
                    dashboard.write(row, 1, value, integer_format)

            row = 16
            dashboard.write(row, 0, "Workbook sheets", header_format)
            for key, sheet_name in SHEET_NAMES.items():
                frame = self.data.get(key)
                if frame is not None and not frame.empty:
                    row += 1
                    dashboard.write_url(row, 0, f"internal:'{sheet_name}'!A1", string=sheet_name)

            for key, dataframe in self.data.items():
                if dataframe is None or dataframe.empty:
                    continue
                self._write_dataframe_split(writer, dataframe, SHEET_NAMES.get(key, key[:31]), header_format, percent_format, decimal_format)
            self._add_excel_charts(writer)
        LOGGER.info("Excel report written to %s", output)

    @staticmethod
    def _excel_display_length(value: Any) -> int:
        """Return a safe display length for mixed/empty dataframe cells.

        pandas nullable dtypes may return ``pd.NA`` from string operations, and
        a column containing only missing values has a NaN quantile.  This helper
        deliberately converts every supported value to a finite integer length.
        """
        if value is None:
            return 0

        try:
            missing = pd.isna(value)
            if isinstance(missing, (bool, np.bool_)) and bool(missing):
                return 0
        except (TypeError, ValueError):
            # Lists, dicts and other non-scalar cells are handled as text below.
            pass

        try:
            text = str(value)
        except Exception:
            return 0

        if text.casefold() in {"nan", "none", "<na>", "nat"}:
            return 0

        # Use the longest line because Excel column width is horizontal.
        return min(max((len(line) for line in text.splitlines()), default=0), 32767)

    @classmethod
    def _estimate_excel_column_width(
        cls,
        series: pd.Series,
        column_name: Any,
        sample_size: int = 5000,
    ) -> float:
        header_length = len(str(column_name))
        if series is None or len(series) == 0:
            return float(min(max(header_length + 2, 11), 46))

        lengths = series.head(sample_size).map(cls._excel_display_length)
        lengths = pd.to_numeric(lengths, errors="coerce")
        lengths = lengths[np.isfinite(lengths.to_numpy(dtype=float, na_value=np.nan))]

        if lengths.empty:
            observed = header_length
        else:
            quantile = lengths.quantile(0.95)
            if pd.isna(quantile) or not np.isfinite(float(quantile)):
                observed = int(lengths.max()) if not lengths.empty else header_length
            else:
                observed = int(math.ceil(float(quantile)))

        return float(min(max(max(header_length, min(45, observed)) + 2, 11), 46))

    def _write_dataframe_split(self, writer, dataframe, sheet_base, header_format, percent_format, decimal_format) -> None:
        max_rows = self.config.excel_max_rows_per_sheet
        chunks = max(1, math.ceil(len(dataframe) / max_rows))
        alternating_row_format = writer.book.add_format({"bg_color": "#F5F8FC"})

        for chunk_index in range(chunks):
            start = chunk_index * max_rows
            end = min((chunk_index + 1) * max_rows, len(dataframe))
            part = dataframe.iloc[start:end].copy()

            suffix = "" if chunks == 1 else f"_{chunk_index + 1}"
            sheet_name = (sheet_base[:31 - len(suffix)] + suffix)[:31]

            part.to_excel(writer, sheet_name=sheet_name, index=False)
            worksheet = writer.sheets[sheet_name]
            worksheet.freeze_panes(1, 1)
            worksheet.set_row(0, 32, header_format)

            if len(part.columns) > 0:
                worksheet.autofilter(
                    0,
                    0,
                    len(part),
                    len(part.columns) - 1,
                )

            for col_index, column in enumerate(part.columns):
                series = part[column]
                width = self._estimate_excel_column_width(series, column)

                lower = str(column).casefold()
                fmt = None
                if any(
                    token in lower
                    for token in ("ratio", "share", "rate", "coefficient")
                ):
                    fmt = percent_format
                elif any(
                    token in lower
                    for token in (
                        "pagerank", "betweenness", "closeness",
                        "eigenvector", "density", "modularity",
                        "slope", "jaccard",
                    )
                ):
                    fmt = decimal_format

                worksheet.set_column(col_index, col_index, width, fmt)

            if len(part) > 0 and len(part.columns) > 0:
                worksheet.conditional_format(
                    1,
                    0,
                    len(part),
                    len(part.columns) - 1,
                    {
                        "type": "formula",
                        "criteria": "=MOD(ROW(),2)=0",
                        "format": alternating_row_format,
                    },
                )

    def _add_excel_charts(self, writer) -> None:
        dashboard = writer.sheets["Dashboard"]
        workbook = writer.book
        yearly = self.data.get("yearly_trends", pd.DataFrame())
        if not yearly.empty and "Yearly_Trends" in writer.sheets:
            chart = workbook.add_chart({"type": "line"})
            columns = {name: idx for idx, name in enumerate(yearly.columns)}
            for name in ("papers", "active_authors", "new_authors"):
                if name in columns:
                    chart.add_series({
                        "name": name.replace("_", " ").title(),
                        "categories": ["Yearly_Trends", 1, columns["publication_year"], len(yearly), columns["publication_year"]],
                        "values": ["Yearly_Trends", 1, columns[name], len(yearly), columns[name]],
                        "marker": {"type": "circle", "size": 5},
                    })
            chart.set_title({"name": "Research community evolution"})
            chart.set_x_axis({"name": "Year"})
            chart.set_y_axis({"name": "Count", "major_gridlines": {"visible": True}})
            chart.set_legend({"position": "bottom"})
            chart.set_style(10)
            dashboard.insert_chart("D5", chart, {"x_scale": 1.35, "y_scale": 1.15})

        authors = self.data.get("authors", pd.DataFrame())
        if not authors.empty:
            top = authors.nlargest(15, "papers")[["author_name", "papers"]]
            start_row = 25
            dashboard.write(start_row, 0, "Top Author")
            dashboard.write(start_row, 1, "Papers")
            for offset, item in enumerate(top.itertuples(index=False), start=1):
                dashboard.write(start_row + offset, 0, item.author_name)
                dashboard.write(start_row + offset, 1, item.papers)
            chart = workbook.add_chart({"type": "bar"})
            chart.add_series({
                "name": "Papers",
                "categories": ["Dashboard", start_row + 1, 0, start_row + len(top), 0],
                "values": ["Dashboard", start_row + 1, 1, start_row + len(top), 1],
            })
            chart.set_title({"name": "Top authors by papers"})
            chart.set_x_axis({"name": "Papers"})
            chart.set_y_axis({"name": "Author"})
            chart.set_legend({"none": True})
            chart.set_style(11)
            dashboard.insert_chart("D22", chart, {"x_scale": 1.35, "y_scale": 1.45})

    def export_network_files(self) -> None:
        if self.graph.number_of_nodes() == 0:
            return
        graphml = nx.Graph(name=self.graph.graph.get("name", "Co-authorship network"))
        gexf = nx.Graph(name=self.graph.graph.get("name", "Co-authorship network"))
        positions = {}
        if self.graph.number_of_nodes() <= 5000 and self.graph.number_of_edges() > 0:
            positions = nx.spring_layout(self.graph, seed=self.config.random_seed, weight="weight", iterations=100)
        for node, attrs in self.graph.nodes(data=True):
            clean = {k: safe_scalar(v) for k, v in attrs.items() if k != "viz" and not (isinstance(v, float) and not np.isfinite(v))}
            graphml.add_node(node, **clean)
            gexf_attrs = dict(clean)
            community = int(attrs.get("community", 1))
            r, g, b = hex_to_rgb(community_color(community))
            viz = {"color": {"r": r, "g": g, "b": b, "a": 0.95}, "size": float(10 + 140 * math.sqrt(max(float(attrs.get("pagerank", 0)), 0)))}
            if node in positions:
                x, y = positions[node]
                viz["position"] = {"x": float(x * 10000), "y": float(y * 10000), "z": 0.0}
            gexf_attrs["viz"] = viz
            gexf.add_node(node, **gexf_attrs)
        for source, target, attrs in self.graph.edges(data=True):
            clean = {k: safe_scalar(v) for k, v in attrs.items() if not (isinstance(v, float) and not np.isfinite(v))}
            graphml.add_edge(source, target, **clean)
            gexf.add_edge(source, target, **clean)
        nx.write_graphml(graphml, self.network_dir / "coauthorship.graphml")
        nx.write_gexf(gexf, self.network_dir / "coauthorship.gexf", version="1.2draft")

        pd.DataFrame([{"Id": node, **{k: safe_scalar(v) for k, v in attrs.items()}} for node, attrs in self.graph.nodes(data=True)]).to_csv(self.network_dir / "gephi_nodes.csv", index=False, encoding="utf-8-sig")
        pd.DataFrame([{"Source": source, "Target": target, "Type": "Undirected", **{k: safe_scalar(v) for k, v in attrs.items()}} for source, target, attrs in self.graph.edges(data=True)]).to_csv(self.network_dir / "gephi_edges.csv", index=False, encoding="utf-8-sig")

        self._export_entity_network(self.data.get("institutions", pd.DataFrame()), self.data.get("institution_collaborations", pd.DataFrame()), "institution", "source_institution", "target_institution", "institution_network")
        self._export_entity_network(self.data.get("countries", pd.DataFrame()), self.data.get("country_collaborations", pd.DataFrame()), "country", "source_country", "target_country", "country_network")

    def _export_entity_network(self, nodes_df, edges_df, node_key, source_key, target_key, filename) -> None:
        if nodes_df.empty:
            return
        graph = nx.Graph(name=filename)
        for row in nodes_df.to_dict(orient="records"):
            node = str(row.pop(node_key))
            graph.add_node(node, **{k: safe_scalar(v) for k, v in row.items()})
        if not edges_df.empty:
            for row in edges_df.to_dict(orient="records"):
                source, target = str(row.pop(source_key)), str(row.pop(target_key))
                graph.add_edge(source, target, **{k: safe_scalar(v) for k, v in row.items()})
        nx.write_graphml(graph, self.network_dir / f"{filename}.graphml")
        nx.write_gexf(graph, self.network_dir / f"{filename}.gexf")

    def export_manifest(self) -> None:
        manifest = {
            "database": str(self.config.db_path), "table": self.config.table_name,
            "authors_column": self.config.authors_column, "detected_columns": self.config.detected_columns,
            "identity_mode": self.config.identity_mode,
            "parameters": {
                "min_author_papers": self.config.min_author_papers,
                "min_edge_weight": self.config.min_edge_weight,
                "louvain_resolution": self.config.louvain_resolution,
                "max_team_size": self.config.max_team_size,
                "min_team_papers": self.config.min_team_papers,
            },
            "network_summary": {k: safe_scalar(v) for k, v in self.network_summary.items()},
            "outputs": {
                "excel": "tables/analysis_report.xlsx", "dashboard": "interactive/dashboard.html",
                "interactive_network": "interactive/coauthorship_network.html",
                "gexf": "networks/coauthorship.gexf", "graphml": "networks/coauthorship.graphml",
            },
        }
        (self.config.output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
