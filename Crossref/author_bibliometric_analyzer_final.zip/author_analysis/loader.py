from __future__ import annotations

import logging
import re
import sqlite3
from pathlib import Path
from typing import Iterator, Optional

import pandas as pd

from .config import AnalysisConfig


LOGGER = logging.getLogger(__name__)
_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


COLUMN_CANDIDATES = {
    "id_column": ["id", "article_id", "work_id", "row_id"],
    "year_column": ["publication_year", "published_year", "year", "issued_year"],
    "title_column": ["title", "article_title", "work_title"],
    "abstract_column": ["abstract", "summary"],
    "keywords_column": ["keywords", "keyword", "subjects", "subject"],
    "journal_column": ["journal", "container_title", "journal_name", "source"],
    "doi_column": ["doi", "DOI"],
    "citations_column": [
        "is_referenced_by_count", "citation_count", "citations",
        "cited_by_count", "times_cited",
    ],
}


def quote_identifier(identifier: str) -> str:
    if not _IDENTIFIER_RE.match(identifier):
        raise ValueError(f"Unsafe SQLite identifier: {identifier!r}")
    return f'"{identifier}"'


def connect_readonly(db_path: Path) -> sqlite3.Connection:
    uri = f"file:{db_path.as_posix()}?mode=ro"
    connection = sqlite3.connect(uri, uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only = ON;")
    connection.execute("PRAGMA temp_store = MEMORY;")
    return connection


def get_table_columns(connection: sqlite3.Connection, table_name: str) -> list[str]:
    table = quote_identifier(table_name)
    rows = connection.execute(f"PRAGMA table_info({table})").fetchall()
    return [row["name"] for row in rows]


def table_exists(connection: sqlite3.Connection, table_name: str) -> bool:
    row = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=? LIMIT 1",
        (table_name,),
    ).fetchone()
    return row is not None


def detect_columns(config: AnalysisConfig) -> dict[str, Optional[str]]:
    with connect_readonly(config.db_path) as connection:
        if not table_exists(connection, config.table_name):
            available = [
                row["name"]
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
                ).fetchall()
            ]
            raise ValueError(
                f"Table {config.table_name!r} was not found. Available tables: {available}"
            )

        columns = get_table_columns(connection, config.table_name)

    if config.authors_column not in columns:
        raise ValueError(
            f"Column {config.authors_column!r} was not found in table "
            f"{config.table_name!r}. Available columns: {columns}"
        )

    lower_map = {col.casefold(): col for col in columns}
    detected: dict[str, Optional[str]] = {}

    for field_name, candidates in COLUMN_CANDIDATES.items():
        explicit = getattr(config, field_name)
        if explicit:
            if explicit not in columns:
                raise ValueError(
                    f"Configured column {explicit!r} for {field_name} does not exist."
                )
            detected[field_name] = explicit
            continue

        match = None
        for candidate in candidates:
            if candidate.casefold() in lower_map:
                match = lower_map[candidate.casefold()]
                break
        detected[field_name] = match
        setattr(config, field_name, match)

    config.detected_columns = detected
    LOGGER.info("Detected columns: %s", detected)
    return detected


def count_rows(config: AnalysisConfig) -> int:
    table = quote_identifier(config.table_name)
    with connect_readonly(config.db_path) as connection:
        return int(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])


def iter_article_chunks(config: AnalysisConfig) -> Iterator[pd.DataFrame]:
    table = quote_identifier(config.table_name)

    selected = [config.authors_column]
    for column in (
        config.id_column,
        config.year_column,
        config.title_column,
        config.abstract_column,
        config.keywords_column,
        config.journal_column,
        config.doi_column,
        config.citations_column,
    ):
        if column and column not in selected:
            selected.append(column)

    select_sql = ", ".join(quote_identifier(col) for col in selected)
    query = f"SELECT rowid AS __rowid__, {select_sql} FROM {table}"

    if config.max_papers:
        query += f" LIMIT {int(config.max_papers)}"

    with connect_readonly(config.db_path) as connection:
        yield from pd.read_sql_query(
            query,
            connection,
            chunksize=config.chunk_size,
        )
