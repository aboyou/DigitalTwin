from __future__ import annotations

import itertools
import logging
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Optional

import networkx as nx
import numpy as np
import pandas as pd
from tqdm import tqdm

from .config import AnalysisConfig
from .loader import count_rows, detect_columns, iter_article_chunks
from .normalization import AuthorResolver, compact_ws, parse_json_array, safe_scalar


LOGGER = logging.getLogger(__name__)


@dataclass
class AuthorAccumulator:
    author_id: str
    display_names: Counter = field(default_factory=Counter)
    normalized_names: Counter = field(default_factory=Counter)
    given_names: Counter = field(default_factory=Counter)
    family_names: Counter = field(default_factory=Counter)
    orcids: set[str] = field(default_factory=set)
    affiliations: Counter = field(default_factory=Counter)
    institutions: Counter = field(default_factory=Counter)
    countries: Counter = field(default_factory=Counter)
    years: Counter = field(default_factory=Counter)
    journals: Counter = field(default_factory=Counter)
    papers: int = 0
    first_author_papers: int = 0
    additional_author_papers: int = 0
    unknown_sequence_papers: int = 0
    total_citations: float = 0.0
    citation_values: list[float] = field(default_factory=list)
    team_sizes: list[int] = field(default_factory=list)

    def preferred_name(self) -> str:
        return self.display_names.most_common(1)[0][0] if self.display_names else self.author_id


@dataclass
class EntityAccumulator:
    name: str
    papers: int = 0
    first_author_papers: int = 0
    authors: set[str] = field(default_factory=set)
    years: Counter = field(default_factory=Counter)
    citations: float = 0.0


class BibliometricAnalyzer:
    def __init__(self, config: AnalysisConfig) -> None:
        self.config = config
        self.resolver = AuthorResolver(config.identity_mode)

        self.authors: dict[str, AuthorAccumulator] = {}
        self.edge_counts: Counter[tuple[str, str]] = Counter()
        self.edge_first_year: dict[tuple[str, str], int] = {}
        self.edge_last_year: dict[tuple[str, str], int] = {}

        self.institutions: dict[str, EntityAccumulator] = {}
        self.countries: dict[str, EntityAccumulator] = {}
        self.institution_edges: Counter[tuple[str, str]] = Counter()
        self.country_edges: Counter[tuple[str, str]] = Counter()

        self.recurring_teams: Counter[tuple[str, ...]] = Counter()
        self.exact_teams: Counter[tuple[str, ...]] = Counter()

        self.year_stats: dict[int, Counter] = defaultdict(Counter)
        self.author_year_counts: Counter[tuple[str, int]] = Counter()

        self.paper_records: list[dict[str, Any]] = []
        self.paper_author_rows: list[dict[str, Any]] = []
        self.parse_errors: list[dict[str, Any]] = []
        self.duplicate_candidates: list[dict[str, Any]] = []

        self.quality = Counter()
        self.graph: nx.Graph = nx.Graph()
        self.community_map: dict[str, int] = {}
        self.network_summary: dict[str, Any] = {}
        self.topic_results: dict[str, pd.DataFrame] = {}

        self._seen_author_year: set[tuple[str, int]] = set()
        self._seen_author_global: set[str] = set()
        self._processed_papers = 0

    def run(self) -> dict[str, pd.DataFrame]:
        self.config.validate()
        detect_columns(self.config)
        self._ingest_database()
        self._build_network()
        self._detect_communities_and_metrics()
        self._build_duplicate_candidates()
        if self.config.enable_topic_analysis:
            self._analyze_topics()
        return self.to_dataframes()

    def _ingest_database(self) -> None:
        total = min(count_rows(self.config), self.config.max_papers or 10**30)
        progress = tqdm(total=total, desc="Reading articles", unit="paper")

        for chunk in iter_article_chunks(self.config):
            for row in chunk.to_dict(orient="records"):
                self._process_article(row)
                progress.update(1)
        progress.close()

        LOGGER.info(
            "Processed %s papers, %s unique author identities, %s coauthor pairs.",
            self._processed_papers,
            len(self.authors),
            len(self.edge_counts),
        )

    def _process_article(self, row: dict[str, Any]) -> None:
        self._processed_papers += 1
        self.quality["rows_seen"] += 1

        rowid = int(row.get("__rowid__") or self._processed_papers)
        paper_id = safe_scalar(row.get(self.config.id_column)) if self.config.id_column else rowid
        if paper_id in {"", None}:
            paper_id = rowid

        year = self._parse_year(row.get(self.config.year_column)) if self.config.year_column else None
        title = compact_ws(row.get(self.config.title_column)) if self.config.title_column else ""
        abstract = compact_ws(row.get(self.config.abstract_column)) if self.config.abstract_column else ""
        keywords = compact_ws(row.get(self.config.keywords_column)) if self.config.keywords_column else ""
        journal = compact_ws(row.get(self.config.journal_column)) if self.config.journal_column else ""
        doi = compact_ws(row.get(self.config.doi_column)) if self.config.doi_column else ""
        citations = self._parse_number(row.get(self.config.citations_column)) if self.config.citations_column else 0.0

        raw_authors, error = parse_json_array(row.get(self.config.authors_column))
        if error:
            self.quality["invalid_authors_json"] += 1
            if len(self.parse_errors) < 50_000:
                self.parse_errors.append(
                    {
                        "rowid": rowid,
                        "paper_id": paper_id,
                        "title": title,
                        "error": error,
                        "raw_preview": compact_ws(row.get(self.config.authors_column))[:500],
                    }
                )
            return

        if not raw_authors:
            self.quality["papers_without_authors"] += 1
            return

        resolved = []
        seen_ids = set()
        for raw in raw_authors:
            author = self.resolver.resolve(raw)
            if not author:
                self.quality["author_entries_without_name"] += 1
                continue
            if author.author_id in seen_ids:
                self.quality["duplicate_author_inside_paper"] += 1
                continue
            seen_ids.add(author.author_id)
            resolved.append(author)

        if not resolved:
            self.quality["papers_without_resolvable_authors"] += 1
            return

        self.quality["papers_with_authors"] += 1
        self.quality["author_occurrences"] += len(resolved)
        team_size = len(resolved)
        author_ids = [author.author_id for author in resolved]

        unique_institutions = sorted({
            institution for author in resolved for institution in author.institutions
        })
        unique_countries = sorted({
            country for author in resolved for country in author.countries
        })

        if unique_institutions:
            self.quality["papers_with_affiliation"] += 1
        if unique_countries:
            self.quality["papers_with_country"] += 1
        if len(unique_institutions) > 1:
            self.quality["cross_institution_papers"] += 1
        if len(unique_countries) > 1:
            self.quality["international_papers"] += 1

        first_author_id = next(
            (author.author_id for author in resolved if author.sequence == "first"),
            resolved[0].author_id,
        )
        first_author = next(
            author for author in resolved if author.author_id == first_author_id
        )

        for position, author in enumerate(resolved, start=1):
            acc = self.authors.setdefault(
                author.author_id,
                AuthorAccumulator(author_id=author.author_id),
            )
            acc.display_names[author.display_name] += 1
            acc.normalized_names[author.normalized_name] += 1
            if author.given:
                acc.given_names[author.given] += 1
            if author.family:
                acc.family_names[author.family] += 1
            if author.orcid:
                acc.orcids.add(author.orcid)
                self.quality["author_occurrences_with_orcid"] += 1
            for affiliation in author.affiliations:
                acc.affiliations[affiliation] += 1
            for institution in author.institutions:
                acc.institutions[institution] += 1
            for country in author.countries:
                acc.countries[country] += 1
            if year is not None:
                acc.years[year] += 1
                self.author_year_counts[(author.author_id, year)] += 1
            if journal:
                acc.journals[journal] += 1

            acc.papers += 1
            if author.author_id == first_author_id:
                acc.first_author_papers += 1
            elif author.sequence == "additional":
                acc.additional_author_papers += 1
            else:
                acc.unknown_sequence_papers += 1

            acc.total_citations += citations
            acc.citation_values.append(citations)
            acc.team_sizes.append(team_size)

            if self.config.export_paper_authors:
                self.paper_author_rows.append(
                    {
                        "paper_id": paper_id,
                        "rowid": rowid,
                        "publication_year": year,
                        "title": title,
                        "doi": doi,
                        "journal": journal,
                        "author_position": position,
                        "author_id": author.author_id,
                        "author_name": author.display_name,
                        "orcid": author.orcid or "",
                        "sequence": author.sequence,
                        "affiliations": " | ".join(author.affiliations),
                        "institutions": " | ".join(author.institutions),
                        "countries": " | ".join(author.countries),
                    }
                )

            for institution in author.institutions:
                entity = self.institutions.setdefault(
                    institution, EntityAccumulator(name=institution)
                )
                entity.authors.add(author.author_id)
            for country in author.countries:
                entity = self.countries.setdefault(country, EntityAccumulator(name=country))
                entity.authors.add(author.author_id)

        for institution in unique_institutions:
            entity = self.institutions.setdefault(
                institution, EntityAccumulator(name=institution)
            )
            entity.papers += 1
            entity.citations += citations
            if year is not None:
                entity.years[year] += 1
            if institution in first_author.institutions:
                entity.first_author_papers += 1

        for country in unique_countries:
            entity = self.countries.setdefault(country, EntityAccumulator(name=country))
            entity.papers += 1
            entity.citations += citations
            if year is not None:
                entity.years[year] += 1
            if country in first_author.countries:
                entity.first_author_papers += 1

        if team_size <= self.config.network_max_authors_per_paper:
            for source, target in itertools.combinations(sorted(author_ids), 2):
                pair = (source, target)
                self.edge_counts[pair] += 1
                if year is not None:
                    self.edge_first_year[pair] = min(
                        year, self.edge_first_year.get(pair, year)
                    )
                    self.edge_last_year[pair] = max(
                        year, self.edge_last_year.get(pair, year)
                    )
        else:
            self.quality["network_skipped_large_team_papers"] += 1

        for source, target in itertools.combinations(unique_institutions, 2):
            self.institution_edges[(source, target)] += 1
        for source, target in itertools.combinations(unique_countries, 2):
            self.country_edges[(source, target)] += 1

        exact_signature = tuple(sorted(author_ids))
        self.exact_teams[exact_signature] += 1

        if self.config.min_team_size <= team_size <= self.config.team_combination_max_authors:
            generated = 0
            for size in range(
                self.config.min_team_size,
                min(self.config.max_team_size, team_size) + 1,
            ):
                for team in itertools.combinations(sorted(author_ids), size):
                    self.recurring_teams[team] += 1
                    generated += 1
                    if generated >= self.config.max_team_combinations_per_paper:
                        self.quality["team_combinations_truncated_papers"] += 1
                        break
                if generated >= self.config.max_team_combinations_per_paper:
                    break

        if year is not None:
            ys = self.year_stats[year]
            ys["papers"] += 1
            ys["author_occurrences"] += team_size
            ys["team_size_sum"] += team_size
            ys["cross_institution_papers"] += int(len(unique_institutions) > 1)
            ys["international_papers"] += int(len(unique_countries) > 1)
            ys["citations"] += citations

            for author_id in author_ids:
                if (author_id, year) not in self._seen_author_year:
                    ys["active_authors"] += 1
                    self._seen_author_year.add((author_id, year))
                if author_id not in self._seen_author_global:
                    ys["new_authors"] += 1
                    self._seen_author_global.add(author_id)

        if self.config.export_papers:
            self.paper_records.append(
                {
                    "paper_id": paper_id,
                    "rowid": rowid,
                    "publication_year": year,
                    "title": title,
                    "abstract": abstract,
                    "keywords": keywords,
                    "journal": journal,
                    "doi": doi,
                    "citations": citations,
                    "team_size": team_size,
                    "author_ids": " | ".join(author_ids),
                    "author_names": " | ".join(a.display_name for a in resolved),
                    "institution_count": len(unique_institutions),
                    "institutions": " | ".join(unique_institutions),
                    "country_count": len(unique_countries),
                    "countries": " | ".join(unique_countries),
                    "cross_institution": int(len(unique_institutions) > 1),
                    "international_collaboration": int(len(unique_countries) > 1),
                }
            )

    def _build_network(self) -> None:
        graph = nx.Graph(name="Co-authorship network")
        eligible_authors = {
            author_id
            for author_id, acc in self.authors.items()
            if acc.papers >= self.config.min_author_papers
        }

        for author_id in eligible_authors:
            acc = self.authors[author_id]
            graph.add_node(
                author_id,
                label=acc.preferred_name(),
                papers=int(acc.papers),
                first_author_papers=int(acc.first_author_papers),
                orcid=next(iter(acc.orcids), ""),
                primary_institution=acc.institutions.most_common(1)[0][0] if acc.institutions else "",
                primary_country=acc.countries.most_common(1)[0][0] if acc.countries else "",
                first_year=min(acc.years) if acc.years else "",
                last_year=max(acc.years) if acc.years else "",
                total_citations=float(acc.total_citations),
            )

        for (source, target), weight in self.edge_counts.items():
            if (
                weight >= self.config.min_edge_weight
                and source in eligible_authors
                and target in eligible_authors
            ):
                graph.add_edge(
                    source,
                    target,
                    weight=int(weight),
                    distance=1.0 / float(weight),
                    first_year=self.edge_first_year.get((source, target), ""),
                    last_year=self.edge_last_year.get((source, target), ""),
                )

        self.graph = graph
        LOGGER.info(
            "Analysis graph: %s nodes, %s edges.",
            graph.number_of_nodes(),
            graph.number_of_edges(),
        )

    def _detect_communities_and_metrics(self) -> None:
        graph = self.graph
        n = graph.number_of_nodes()
        m = graph.number_of_edges()

        if n == 0:
            self.network_summary = {
                "nodes": 0,
                "edges": 0,
                "density": 0,
                "components": 0,
                "giant_component_ratio": 0,
                "modularity": 0,
            }
            return

        if m:
            communities = list(
                nx.community.louvain_communities(
                    graph,
                    weight="weight",
                    resolution=self.config.louvain_resolution,
                    seed=self.config.random_seed,
                )
            )
        else:
            communities = [{node} for node in graph.nodes]

        communities = sorted(communities, key=len, reverse=True)
        self.community_map = {
            node: community_id
            for community_id, nodes in enumerate(communities, start=1)
            for node in nodes
        }
        modularity = (
            nx.community.modularity(graph, communities, weight="weight")
            if m and len(communities) > 1
            else 0.0
        )

        degree = dict(graph.degree())
        weighted_degree = dict(graph.degree(weight="weight"))
        pagerank = nx.pagerank(graph, weight="weight") if m else {node: 1 / n for node in graph}
        clustering = nx.clustering(graph, weight="weight") if m else {node: 0.0 for node in graph}
        core = nx.core_number(graph) if m else {node: 0 for node in graph}

        if m:
            if n <= self.config.exact_betweenness_max_nodes:
                LOGGER.info("Calculating exact betweenness centrality.")
                betweenness = nx.betweenness_centrality(
                    graph, weight="distance", normalized=True
                )
            else:
                samples = min(self.config.approximate_betweenness_samples, n)
                LOGGER.info(
                    "Calculating approximate betweenness centrality with %s samples.",
                    samples,
                )
                betweenness = nx.betweenness_centrality(
                    graph,
                    k=samples,
                    weight="distance",
                    normalized=True,
                    seed=self.config.random_seed,
                )
        else:
            betweenness = {node: 0.0 for node in graph}

        closeness = {node: np.nan for node in graph}
        if n <= self.config.closeness_max_nodes and m:
            LOGGER.info("Calculating closeness centrality.")
            for component in nx.connected_components(graph):
                subgraph = graph.subgraph(component)
                closeness.update(nx.closeness_centrality(subgraph, distance="distance"))

        eigenvector = {node: np.nan for node in graph}
        if n <= self.config.eigenvector_max_nodes and m:
            try:
                eigenvector = nx.eigenvector_centrality(
                    graph, max_iter=2_000, tol=1e-8, weight="weight"
                )
            except nx.PowerIterationFailedConvergence:
                LOGGER.warning("Eigenvector centrality did not converge.")

        participation = self._participation_coefficient(graph, self.community_map)
        within_z = self._within_module_degree_z(graph, self.community_map)
        bridge_coefficient = self._bridging_coefficient(graph)
        bridging_centrality = {
            node: float(betweenness.get(node, 0.0))
            * float(bridge_coefficient.get(node, 0.0))
            for node in graph
        }

        for node in graph:
            graph.nodes[node].update(
                {
                    "community": int(self.community_map.get(node, 0)),
                    "degree": int(degree.get(node, 0)),
                    "weighted_degree": float(weighted_degree.get(node, 0.0)),
                    "pagerank": float(pagerank.get(node, 0.0)),
                    "betweenness": float(betweenness.get(node, 0.0)),
                    "closeness": float(closeness.get(node, np.nan)),
                    "eigenvector": float(eigenvector.get(node, np.nan)),
                    "clustering": float(clustering.get(node, 0.0)),
                    "core_number": int(core.get(node, 0)),
                    "participation_coefficient": float(participation.get(node, 0.0)),
                    "within_module_z": float(within_z.get(node, 0.0)),
                    "bridging_centrality": float(bridging_centrality.get(node, 0.0)),
                    "network_role": self._network_role(
                        within_z.get(node, 0.0), participation.get(node, 0.0)
                    ),
                }
            )

        components = list(nx.connected_components(graph))
        giant = max((len(component) for component in components), default=0)
        assortativity = np.nan
        if m > 1:
            try:
                assortativity = nx.degree_assortativity_coefficient(graph)
            except Exception:
                pass

        self.network_summary = {
            "nodes": n,
            "edges": m,
            "density": nx.density(graph),
            "components": len(components),
            "giant_component_nodes": giant,
            "giant_component_ratio": giant / n if n else 0.0,
            "average_degree": (2 * m / n) if n else 0.0,
            "average_weighted_degree": sum(weighted_degree.values()) / n if n else 0.0,
            "average_clustering": nx.average_clustering(graph, weight="weight") if m else 0.0,
            "modularity": modularity,
            "communities": len(communities),
            "degree_assortativity": assortativity,
        }

    @staticmethod
    def _participation_coefficient(
        graph: nx.Graph, community_map: dict[str, int]
    ) -> dict[str, float]:
        result: dict[str, float] = {}
        for node in graph:
            total = float(graph.degree(node, weight="weight"))
            if total <= 0:
                result[node] = 0.0
                continue
            per_community = Counter()
            for neighbor, attrs in graph[node].items():
                per_community[community_map.get(neighbor, 0)] += float(attrs.get("weight", 1.0))
            result[node] = 1.0 - sum((weight / total) ** 2 for weight in per_community.values())
        return result

    @staticmethod
    def _within_module_degree_z(
        graph: nx.Graph, community_map: dict[str, int]
    ) -> dict[str, float]:
        internal_degree: dict[str, float] = {}
        grouped: dict[int, list[float]] = defaultdict(list)

        for node in graph:
            community = community_map.get(node, 0)
            value = sum(
                float(attrs.get("weight", 1.0))
                for neighbor, attrs in graph[node].items()
                if community_map.get(neighbor, 0) == community
            )
            internal_degree[node] = value
            grouped[community].append(value)

        stats = {
            community: (float(np.mean(values)), float(np.std(values)))
            for community, values in grouped.items()
        }
        result = {}
        for node, value in internal_degree.items():
            mean, std = stats[community_map.get(node, 0)]
            result[node] = (value - mean) / std if std > 0 else 0.0
        return result

    @staticmethod
    def _bridging_coefficient(graph: nx.Graph) -> dict[str, float]:
        degrees = dict(graph.degree())
        result = {}
        for node in graph:
            degree = degrees.get(node, 0)
            if degree == 0:
                result[node] = 0.0
                continue
            denominator = sum(
                1.0 / max(degrees.get(neighbor, 1), 1)
                for neighbor in graph.neighbors(node)
            )
            result[node] = (1.0 / degree) / denominator if denominator > 0 else 0.0
        return result

    @staticmethod
    def _network_role(z_score: float, participation: float) -> str:
        if z_score >= 2.5:
            if participation <= 0.30:
                return "Provincial hub"
            if participation <= 0.75:
                return "Connector hub"
            return "Kinless hub"
        if participation <= 0.05:
            return "Ultra-peripheral"
        if participation <= 0.62:
            return "Peripheral"
        if participation <= 0.80:
            return "Connector"
        return "Kinless"

    def _build_duplicate_candidates(self) -> None:
        by_name: dict[str, list[str]] = defaultdict(list)
        for author_id, acc in self.authors.items():
            if acc.normalized_names:
                by_name[acc.normalized_names.most_common(1)[0][0]].append(author_id)

        for normalized, author_ids in by_name.items():
            if len(author_ids) < 2:
                continue
            records = [self.authors[author_id] for author_id in author_ids]
            for a, b in itertools.combinations(records, 2):
                institutions_a = set(a.institutions)
                institutions_b = set(b.institutions)
                countries_a = set(a.countries)
                countries_b = set(b.countries)
                score = 0
                reasons = []
                if institutions_a & institutions_b:
                    score += 3
                    reasons.append("same institution")
                if countries_a & countries_b:
                    score += 1
                    reasons.append("same country")
                if a.orcids and b.orcids and a.orcids == b.orcids:
                    score += 10
                    reasons.append("same ORCID")
                if score:
                    self.duplicate_candidates.append(
                        {
                            "normalized_name": normalized,
                            "author_id_1": a.author_id,
                            "name_1": a.preferred_name(),
                            "orcid_1": "; ".join(sorted(a.orcids)),
                            "institutions_1": "; ".join(x for x, _ in a.institutions.most_common(3)),
                            "author_id_2": b.author_id,
                            "name_2": b.preferred_name(),
                            "orcid_2": "; ".join(sorted(b.orcids)),
                            "institutions_2": "; ".join(x for x, _ in b.institutions.most_common(3)),
                            "similarity_score": score,
                            "reasons": "; ".join(reasons),
                        }
                    )

    def _analyze_topics(self) -> None:
        if not self.paper_records:
            return
        papers = pd.DataFrame(self.paper_records)
        if "title" not in papers.columns:
            return

        texts = (
            papers["title"].fillna("").astype(str)
            + " "
            + papers.get("abstract", pd.Series("", index=papers.index)).fillna("").astype(str)
            + " "
            + papers.get("keywords", pd.Series("", index=papers.index)).fillna("").astype(str)
        ).str.strip()

        valid_mask = texts.str.len() >= 20
        if int(valid_mask.sum()) < self.config.topic_min_documents:
            LOGGER.info("Topic analysis skipped: too few text-bearing papers.")
            return

        try:
            from sklearn.cluster import MiniBatchKMeans
            from sklearn.feature_extraction.text import TfidfVectorizer
        except ImportError:
            LOGGER.warning("scikit-learn is not installed; topic analysis skipped.")
            return

        valid_texts = texts[valid_mask]
        n_docs = len(valid_texts)
        n_clusters = max(
            2,
            min(self.config.topic_max_clusters, int(round(math.sqrt(n_docs / 2)))),
        )

        vectorizer = TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 2),
            min_df=2,
            max_df=0.90,
            max_features=self.config.topic_max_features,
            token_pattern=r"(?u)\b[^\W\d_][\w\-]{2,}\b",
        )

        try:
            matrix = vectorizer.fit_transform(valid_texts)
        except ValueError:
            LOGGER.warning("Topic analysis skipped: empty TF-IDF vocabulary.")
            return

        if matrix.shape[1] < 2:
            return
        n_clusters = min(n_clusters, matrix.shape[1], n_docs)
        if n_clusters < 2:
            return

        model = MiniBatchKMeans(
            n_clusters=n_clusters,
            random_state=self.config.random_seed,
            batch_size=min(2_048, max(256, n_docs)),
            n_init="auto",
        )
        labels = model.fit_predict(matrix)
        terms = np.asarray(vectorizer.get_feature_names_out())

        topic_rows = []
        for topic_id, center in enumerate(model.cluster_centers_, start=1):
            top_indices = center.argsort()[::-1][: self.config.topic_top_terms]
            top_terms = [terms[index] for index in top_indices]
            count = int((labels == topic_id - 1).sum())
            topic_rows.append(
                {
                    "topic_id": topic_id,
                    "paper_count": count,
                    "share": count / n_docs,
                    "top_terms": "; ".join(top_terms),
                    "topic_label": " / ".join(top_terms[:4]),
                }
            )

        papers["topic_id"] = np.nan
        papers.loc[valid_mask, "topic_id"] = labels + 1

        dominant_communities = []
        community_span = []
        for author_ids_text in papers["author_ids"].fillna(""):
            author_ids = [x.strip() for x in str(author_ids_text).split("|") if x.strip()]
            counts = Counter(
                self.community_map.get(author_id, 0)
                for author_id in author_ids
                if self.community_map.get(author_id, 0)
            )
            dominant_communities.append(counts.most_common(1)[0][0] if counts else 0)
            community_span.append(len(counts))

        papers["dominant_author_community"] = dominant_communities
        papers["author_community_span"] = community_span

        matrix_df = (
            papers.dropna(subset=["topic_id"])
            .groupby(["dominant_author_community", "topic_id"])
            .size()
            .reset_index(name="paper_count")
        )

        self.topic_results = {
            "topics": pd.DataFrame(topic_rows).sort_values("paper_count", ascending=False),
            "paper_topics": papers,
            "community_topic_matrix": matrix_df,
        }

    def to_dataframes(self) -> dict[str, pd.DataFrame]:
        authors_df = self._authors_dataframe()
        edges_df = self._edges_dataframe(authors_df)
        communities_df = self._communities_dataframe(authors_df, edges_df)
        institutions_df = self._entities_dataframe(self.institutions, "institution")
        countries_df = self._entities_dataframe(self.countries, "country")
        institution_edges_df = self._entity_edges_dataframe(
            self.institution_edges, "source_institution", "target_institution"
        )
        country_edges_df = self._entity_edges_dataframe(
            self.country_edges, "source_country", "target_country"
        )
        recurring_teams_df = self._teams_dataframe(self.recurring_teams, exact=False)
        exact_teams_df = self._teams_dataframe(self.exact_teams, exact=True)
        yearly_df = self._yearly_dataframe()

        papers_df = pd.DataFrame(self.paper_records)
        paper_authors_df = pd.DataFrame(self.paper_author_rows)
        parse_errors_df = pd.DataFrame(self.parse_errors)
        duplicates_df = pd.DataFrame(self.duplicate_candidates)

        summary_rows = [
            {"metric": key, "value": value}
            for key, value in {
                **self.network_summary,
                "database_rows_processed": self.quality.get("rows_seen", 0),
                "papers_with_authors": self.quality.get("papers_with_authors", 0),
                "unique_author_identities_all": len(self.authors),
                "institutions": len(self.institutions),
                "countries": len(self.countries),
                "recurrent_teams": len(recurring_teams_df),
                "invalid_authors_json": self.quality.get("invalid_authors_json", 0),
            }.items()
        ]
        summary_df = pd.DataFrame(summary_rows)

        quality_rows = [
            {"metric": key, "value": value}
            for key, value in sorted(self.quality.items())
        ]
        if self.quality.get("author_occurrences"):
            quality_rows.extend(
                [
                    {
                        "metric": "orcid_occurrence_coverage",
                        "value": self.quality.get("author_occurrences_with_orcid", 0)
                        / self.quality["author_occurrences"],
                    },
                    {
                        "metric": "affiliation_paper_coverage",
                        "value": self.quality.get("papers_with_affiliation", 0)
                        / max(self.quality.get("papers_with_authors", 1), 1),
                    },
                    {
                        "metric": "country_paper_coverage",
                        "value": self.quality.get("papers_with_country", 0)
                        / max(self.quality.get("papers_with_authors", 1), 1),
                    },
                ]
            )
        quality_df = pd.DataFrame(quality_rows)

        result = {
            "summary": summary_df,
            "authors": authors_df,
            "collaborations": edges_df,
            "communities": communities_df,
            "recurring_teams": recurring_teams_df,
            "exact_teams": exact_teams_df,
            "institutions": institutions_df,
            "institution_collaborations": institution_edges_df,
            "countries": countries_df,
            "country_collaborations": country_edges_df,
            "yearly_trends": yearly_df,
            "papers": papers_df,
            "paper_authors": paper_authors_df,
            "data_quality": quality_df,
            "parse_errors": parse_errors_df,
            "possible_duplicate_authors": duplicates_df,
        }
        result.update(self.topic_results)
        return result

    def _authors_dataframe(self) -> pd.DataFrame:
        rows = []
        for author_id, acc in self.authors.items():
            if author_id not in self.graph:
                continue
            node = self.graph.nodes[author_id]
            years = sorted(acc.years)
            year_span = (years[-1] - years[0] + 1) if years else 0
            active_years = len(years)
            rows.append(
                {
                    "author_id": author_id,
                    "author_name": acc.preferred_name(),
                    "orcid": "; ".join(sorted(acc.orcids)),
                    "papers": acc.papers,
                    "first_author_papers": acc.first_author_papers,
                    "first_author_ratio": acc.first_author_papers / acc.papers if acc.papers else 0,
                    "additional_author_papers": acc.additional_author_papers,
                    "first_year": years[0] if years else np.nan,
                    "last_year": years[-1] if years else np.nan,
                    "active_years": active_years,
                    "research_span": year_span,
                    "activity_continuity": active_years / year_span if year_span else np.nan,
                    "recent_activity_slope": self._activity_slope(acc.years),
                    "mean_team_size": float(np.mean(acc.team_sizes)) if acc.team_sizes else np.nan,
                    "total_citations": acc.total_citations,
                    "mean_citations_per_paper": acc.total_citations / acc.papers if acc.papers else 0,
                    "h_index_in_dataset": self._h_index(acc.citation_values),
                    "primary_institution": acc.institutions.most_common(1)[0][0] if acc.institutions else "",
                    "institutions": " | ".join(x for x, _ in acc.institutions.most_common()),
                    "primary_country": acc.countries.most_common(1)[0][0] if acc.countries else "",
                    "countries": " | ".join(x for x, _ in acc.countries.most_common()),
                    "top_journals": " | ".join(x for x, _ in acc.journals.most_common(5)),
                    "community": node.get("community", 0),
                    "network_role": node.get("network_role", ""),
                    "degree": node.get("degree", 0),
                    "weighted_degree": node.get("weighted_degree", 0),
                    "pagerank": node.get("pagerank", 0),
                    "betweenness": node.get("betweenness", 0),
                    "closeness": node.get("closeness", np.nan),
                    "eigenvector": node.get("eigenvector", np.nan),
                    "clustering_coefficient": node.get("clustering", 0),
                    "core_number": node.get("core_number", 0),
                    "participation_coefficient": node.get("participation_coefficient", 0),
                    "within_module_z": node.get("within_module_z", 0),
                    "bridging_centrality": node.get("bridging_centrality", 0),
                }
            )
        if not rows:
            return pd.DataFrame()
        return pd.DataFrame(rows).sort_values(
            ["pagerank", "papers"], ascending=[False, False]
        )

    def _edges_dataframe(self, authors_df: pd.DataFrame) -> pd.DataFrame:
        if self.graph.number_of_edges() == 0:
            return pd.DataFrame()
        names = authors_df.set_index("author_id")["author_name"].to_dict() if not authors_df.empty else {}
        papers = {author_id: acc.papers for author_id, acc in self.authors.items()}
        rows = []
        for source, target, attrs in self.graph.edges(data=True):
            shared = int(attrs.get("weight", 1))
            union = papers[source] + papers[target] - shared
            rows.append(
                {
                    "source": source,
                    "target": target,
                    "source_name": names.get(source, source),
                    "target_name": names.get(target, target),
                    "shared_papers": shared,
                    "jaccard_collaboration": shared / union if union else 0,
                    "source_dependency": shared / papers[source] if papers[source] else 0,
                    "target_dependency": shared / papers[target] if papers[target] else 0,
                    "first_collaboration_year": attrs.get("first_year", ""),
                    "last_collaboration_year": attrs.get("last_year", ""),
                    "source_community": self.community_map.get(source, 0),
                    "target_community": self.community_map.get(target, 0),
                    "cross_community": int(
                        self.community_map.get(source) != self.community_map.get(target)
                    ),
                }
            )
        return pd.DataFrame(rows).sort_values(
            ["shared_papers", "jaccard_collaboration"], ascending=[False, False]
        )

    def _communities_dataframe(
        self, authors_df: pd.DataFrame, edges_df: pd.DataFrame
    ) -> pd.DataFrame:
        if authors_df.empty:
            return pd.DataFrame()

        rows = []
        for community, group in authors_df.groupby("community"):
            member_ids = set(group["author_id"])
            internal = 0
            external = 0
            if not edges_df.empty:
                for edge in edges_df.itertuples():
                    source_in = edge.source in member_ids
                    target_in = edge.target in member_ids
                    if source_in and target_in:
                        internal += int(edge.shared_papers)
                    elif source_in or target_in:
                        external += int(edge.shared_papers)

            institution_counts = Counter(group["primary_institution"].replace("", np.nan).dropna())
            country_counts = Counter(group["primary_country"].replace("", np.nan).dropna())
            rows.append(
                {
                    "community": community,
                    "author_count": len(group),
                    "total_author_papers": int(group["papers"].sum()),
                    "mean_papers_per_author": float(group["papers"].mean()),
                    "first_year": group["first_year"].min(),
                    "last_year": group["last_year"].max(),
                    "internal_collaboration_weight": internal,
                    "external_collaboration_weight": external,
                    "external_share": external / (internal + external) if internal + external else 0,
                    "top_authors": " | ".join(
                        group.nlargest(10, "pagerank")["author_name"].astype(str)
                    ),
                    "top_institutions": " | ".join(name for name, _ in institution_counts.most_common(8)),
                    "top_countries": " | ".join(name for name, _ in country_counts.most_common(8)),
                    "connector_authors": " | ".join(
                        group.nlargest(5, "participation_coefficient")["author_name"].astype(str)
                    ),
                }
            )

        result = pd.DataFrame(rows).sort_values("author_count", ascending=False)
        if "topics" in self.topic_results and "community_topic_matrix" in self.topic_results:
            topic_labels = self.topic_results["topics"].set_index("topic_id")["topic_label"].to_dict()
            matrix = self.topic_results["community_topic_matrix"]
            top_topics = {}
            for community, group in matrix.groupby("dominant_author_community"):
                top_topics[community] = " | ".join(
                    topic_labels.get(int(row.topic_id), f"Topic {int(row.topic_id)}")
                    for row in group.nlargest(5, "paper_count").itertuples()
                )
            result["top_topics"] = result["community"].map(top_topics).fillna("")
        return result

    @staticmethod
    def _entities_dataframe(
        entities: dict[str, EntityAccumulator], column_name: str
    ) -> pd.DataFrame:
        rows = []
        for name, entity in entities.items():
            years = sorted(entity.years)
            rows.append(
                {
                    column_name: name,
                    "papers": entity.papers,
                    "authors": len(entity.authors),
                    "first_author_papers": entity.first_author_papers,
                    "first_year": years[0] if years else np.nan,
                    "last_year": years[-1] if years else np.nan,
                    "total_citations": entity.citations,
                    "mean_citations_per_paper": entity.citations / entity.papers if entity.papers else 0,
                    "activity_slope": BibliometricAnalyzer._activity_slope(entity.years),
                }
            )
        if not rows:
            return pd.DataFrame()
        return pd.DataFrame(rows).sort_values(
            ["papers", "authors"], ascending=[False, False]
        )

    @staticmethod
    def _entity_edges_dataframe(
        counter: Counter[tuple[str, str]], source_name: str, target_name: str
    ) -> pd.DataFrame:
        rows = [
            {source_name: source, target_name: target, "shared_papers": weight}
            for (source, target), weight in counter.items()
        ]
        return pd.DataFrame(rows).sort_values("shared_papers", ascending=False) if rows else pd.DataFrame()

    def _teams_dataframe(self, counter: Counter[tuple[str, ...]], exact: bool) -> pd.DataFrame:
        rows = []
        for team, paper_count in counter.items():
            if paper_count < self.config.min_team_papers:
                continue
            names = [self.authors[author_id].preferred_name() for author_id in team]
            rows.append(
                {
                    "team_size": len(team),
                    "paper_count": paper_count,
                    "author_ids": " | ".join(team),
                    "author_names": " | ".join(names),
                    "exact_full_team": int(exact),
                    "mean_member_papers": float(
                        np.mean([self.authors[author_id].papers for author_id in team])
                    ),
                    "minimum_member_dependency": min(
                        paper_count / max(self.authors[author_id].papers, 1)
                        for author_id in team
                    ),
                }
            )
        if not rows:
            return pd.DataFrame()
        return pd.DataFrame(rows).sort_values(
            ["paper_count", "team_size"], ascending=[False, False]
        )

    def _yearly_dataframe(self) -> pd.DataFrame:
        rows = []
        for year in sorted(self.year_stats):
            stats = self.year_stats[year]
            papers = stats["papers"]
            rows.append(
                {
                    "publication_year": year,
                    "papers": papers,
                    "active_authors": stats["active_authors"],
                    "new_authors": stats["new_authors"],
                    "author_occurrences": stats["author_occurrences"],
                    "mean_team_size": stats["team_size_sum"] / papers if papers else 0,
                    "cross_institution_papers": stats["cross_institution_papers"],
                    "cross_institution_rate": stats["cross_institution_papers"] / papers if papers else 0,
                    "international_papers": stats["international_papers"],
                    "international_collaboration_rate": stats["international_papers"] / papers if papers else 0,
                    "total_citations": stats["citations"],
                }
            )
        return pd.DataFrame(rows)

    @staticmethod
    def _parse_year(value: Any) -> Optional[int]:
        if value is None:
            return None
        try:
            year = int(float(value))
        except (TypeError, ValueError):
            return None
        return year if 1400 <= year <= 2200 else None

    @staticmethod
    def _parse_number(value: Any) -> float:
        if value is None:
            return 0.0
        try:
            number = float(value)
            return number if np.isfinite(number) else 0.0
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _h_index(values: list[float]) -> int:
        ordered = sorted((max(0, int(v)) for v in values), reverse=True)
        h = 0
        for rank, value in enumerate(ordered, start=1):
            if value >= rank:
                h = rank
            else:
                break
        return h

    @staticmethod
    def _activity_slope(year_counter: Counter) -> float:
        if not year_counter:
            return np.nan
        years = sorted(int(year) for year in year_counter)
        if len(years) < 2:
            return 0.0
        all_years = np.arange(years[0], years[-1] + 1)
        counts = np.array([year_counter.get(int(year), 0) for year in all_years])
        return float(np.polyfit(all_years, counts, 1)[0])
