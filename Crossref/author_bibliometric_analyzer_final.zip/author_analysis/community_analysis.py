from __future__ import annotations

import html
import logging
import math
import re
from collections import Counter
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)

_AUTHOR_SEPARATOR_RE = re.compile(r"\s*\|\s*")
_GENERIC_TERMS = {
    "study", "analysis", "method", "methods", "approach", "approaches",
    "model", "models", "modeling", "modelling", "framework", "frameworks",
    "system", "systems", "based", "using", "use", "new", "research",
    "paper", "papers", "result", "results", "application", "applications",
    "data", "digital", "twin", "digital twin", "digital twins",
    "proposed", "development", "design", "performance", "technology",
}


def _split_pipe(value: Any) -> list[str]:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return []
    text = str(value).strip()
    if not text or text.casefold() in {"nan", "none", "<na>"}:
        return []
    return [item.strip() for item in _AUTHOR_SEPARATOR_RE.split(text) if item.strip()]


def _safe_number(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        return number if np.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _paper_key(row: Mapping[str, Any], fallback_index: int) -> str:
    for column in ("paper_id", "id", "doi", "rowid"):
        value = row.get(column)
        if value is not None and str(value).strip() and str(value).casefold() != "nan":
            return str(value).strip()
    return f"row:{fallback_index}"


def _build_document_text(papers: pd.DataFrame) -> pd.Series:
    title = papers.get("title", pd.Series("", index=papers.index)).fillna("").astype(str)
    abstract = papers.get("abstract", pd.Series("", index=papers.index)).fillna("").astype(str)
    keywords = papers.get("keywords", pd.Series("", index=papers.index)).fillna("").astype(str)

    # Titles and keywords are intentionally repeated to make the inferred field
    # more representative of the paper's central subject than boilerplate abstract text.
    return (
        title + " " + title + " "
        + keywords + " " + keywords + " "
        + abstract
    ).str.replace(r"\s+", " ", regex=True).str.strip()


def _select_terms(feature_names: np.ndarray, weights: np.ndarray, limit: int) -> list[str]:
    order = np.argsort(weights)[::-1]
    selected: list[str] = []
    for index in order:
        score = float(weights[index])
        if score <= 0:
            break
        term = str(feature_names[index]).strip()
        folded = term.casefold()
        if not term or folded in _GENERIC_TERMS:
            continue
        if len(term) < 3:
            continue
        # Avoid near-duplicate labels such as "industrial control" and
        # "industrial control system" occupying every label position.
        if any(
            folded == existing.casefold()
            or folded in existing.casefold()
            or existing.casefold() in folded
            for existing in selected
        ):
            continue
        selected.append(term)
        if len(selected) >= limit:
            break
    return selected


def build_community_paper_outputs(
    papers: pd.DataFrame,
    author_communities: Mapping[str, int],
    author_names: Mapping[str, str] | None = None,
    author_pagerank: Mapping[str, float] | None = None,
    *,
    field_top_terms: int = 20,
    field_label_terms: int = 5,
    representative_papers: int = 12,
    core_membership_threshold: float = 0.50,
    max_features: int = 20_000,
    min_documents_for_field: int = 3,
    random_seed: int = 42,
) -> dict[str, pd.DataFrame]:
    """Create article lists and inferred research-field profiles per author community.

    A paper may belong to more than one community.  The long output therefore
    stores one row for every paper-community relationship.  A deterministic
    dominant community is also selected using author count, then summed PageRank,
    then the smallest community identifier.
    """
    if papers is None or papers.empty:
        return {
            "community_papers": pd.DataFrame(),
            "community_fields": pd.DataFrame(),
            "community_representative_papers": pd.DataFrame(),
        }

    author_names = author_names or {}
    author_pagerank = author_pagerank or {}
    source = papers.copy().reset_index(drop=True)
    if "paper_id" not in source.columns:
        source["paper_id"] = [
            _paper_key(row, index) for index, row in enumerate(source.to_dict(orient="records"))
        ]

    membership_rows: list[dict[str, Any]] = []
    paper_membership_meta: dict[int, dict[str, Any]] = {}

    for paper_index, row in source.iterrows():
        author_ids = _split_pipe(row.get("author_ids", ""))
        all_author_names = _split_pipe(row.get("author_names", ""))
        fallback_name_by_id = {
            author_id: all_author_names[pos]
            for pos, author_id in enumerate(author_ids)
            if pos < len(all_author_names)
        }

        community_members: dict[int, list[str]] = {}
        for author_id in author_ids:
            community = _safe_int(author_communities.get(author_id), 0)
            if community > 0:
                community_members.setdefault(community, []).append(author_id)

        clustered_count = sum(len(values) for values in community_members.values())
        if clustered_count == 0:
            continue

        rankings = []
        for community, member_ids in community_members.items():
            rank_sum = sum(_safe_number(author_pagerank.get(author_id), 0.0) for author_id in member_ids)
            rankings.append((len(member_ids), rank_sum, -community, community))
        dominant_community = max(rankings)[3]
        tied_by_count = sorted(
            community
            for community, members in community_members.items()
            if len(members) == max(len(values) for values in community_members.values())
        )
        community_count = len(community_members)

        paper_membership_meta[paper_index] = {
            "dominant_community": dominant_community,
            "community_count": community_count,
            "tied_by_count": tied_by_count,
        }

        base = {
            "paper_index": paper_index,
            "paper_id": row.get("paper_id", ""),
            "rowid": row.get("rowid", ""),
            "publication_year": row.get("publication_year", ""),
            "title": row.get("title", ""),
            "journal": row.get("journal", ""),
            "doi": row.get("doi", ""),
            "doi_url": f"https://doi.org/{str(row.get('doi')).strip()}" if str(row.get("doi", "")).strip() and str(row.get("doi", "")).casefold() != "nan" else "",
            "citations": row.get("citations", row.get("citation_count", 0)),
            "team_size": row.get("team_size", len(author_ids)),
            "all_author_ids": row.get("author_ids", ""),
            "all_author_names": row.get("author_names", ""),
            "institutions": row.get("institutions", ""),
            "countries": row.get("countries", ""),
            "topic_id": row.get("topic_id", ""),
        }

        for community, member_ids in sorted(community_members.items()):
            community_author_names = [
                author_names.get(author_id)
                or fallback_name_by_id.get(author_id)
                or author_id
                for author_id in member_ids
            ]
            member_count = len(member_ids)
            share_clustered = member_count / clustered_count
            team_size = max(_safe_int(row.get("team_size"), len(author_ids)), 1)
            share_all = member_count / team_size
            is_dominant = int(community == dominant_community)
            is_core = int(is_dominant or share_clustered >= core_membership_threshold)
            membership_rows.append(
                {
                    **base,
                    "community": community,
                    "community_author_count": member_count,
                    "clustered_author_count": clustered_count,
                    "unclustered_author_count": max(len(author_ids) - clustered_count, 0),
                    "community_author_share": share_clustered,
                    "community_share_of_full_team": share_all,
                    "community_author_ids": " | ".join(member_ids),
                    "community_author_names": " | ".join(community_author_names),
                    "paper_community_count": community_count,
                    "is_cross_community_paper": int(community_count > 1),
                    "is_dominant_community": is_dominant,
                    "is_core_community_paper": is_core,
                    "dominant_community": dominant_community,
                    "dominant_count_tie": int(len(tied_by_count) > 1),
                    "count_tied_communities": " | ".join(map(str, tied_by_count)),
                    "membership_type": "dominant" if is_dominant else "associated",
                }
            )

    community_papers = pd.DataFrame(membership_rows)
    if community_papers.empty:
        return {
            "community_papers": community_papers,
            "community_fields": pd.DataFrame(),
            "community_representative_papers": pd.DataFrame(),
        }

    # Infer a field profile from a global TF-IDF space.  This makes terms
    # discriminative between communities instead of simply returning the most
    # common words in the whole database.
    documents = _build_document_text(source)
    valid_mask = documents.str.len() >= 12
    feature_names = np.array([], dtype=object)
    matrix = None
    vectorizer_error = ""

    try:
        from sklearn.feature_extraction.text import TfidfVectorizer

        valid_document_count = int(valid_mask.sum())
        min_df = 2 if valid_document_count >= 20 else 1
        vectorizer = TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 3),
            min_df=min_df,
            max_df=0.93 if valid_document_count >= 20 else 1.0,
            max_features=max_features,
            sublinear_tf=True,
            token_pattern=r"(?u)\b[^\W\d_][\w\-]{2,}\b",
        )
        matrix_valid = vectorizer.fit_transform(documents[valid_mask])
        feature_names = vectorizer.get_feature_names_out()
        matrix = np.zeros(len(source), dtype=object)
        valid_indices = np.flatnonzero(valid_mask.to_numpy())
        # Store row references instead of densifying the document-term matrix.
        for local_index, paper_index in enumerate(valid_indices):
            matrix[paper_index] = matrix_valid.getrow(local_index)
    except Exception as exc:  # field extraction must never block the network report
        vectorizer_error = f"{type(exc).__name__}: {exc}"
        LOGGER.warning("Community field extraction could not build TF-IDF: %s", vectorizer_error)

    profile_rows: list[dict[str, Any]] = []
    representative_rows: list[dict[str, Any]] = []
    relevance_by_pair: dict[tuple[int, int], float] = {}

    for community, group in community_papers.groupby("community", sort=True):
        unique_group = group.drop_duplicates(subset=["paper_index"]).copy()
        any_papers = len(unique_group)
        dominant_group = unique_group[unique_group["is_dominant_community"] == 1]
        core_group = unique_group[unique_group["is_core_community_paper"] == 1]
        bridge_group = unique_group[unique_group["is_cross_community_paper"] == 1]

        top_terms: list[str] = []
        top_phrases: list[str] = []
        field_label = "Insufficient textual data"
        field_status = "insufficient_text"
        scored: list[tuple[int, float]] = []

        if matrix is not None:
            valid_members = []
            weights = []
            for membership in unique_group.itertuples():
                sparse_row = matrix[int(membership.paper_index)]
                if sparse_row is not None and not isinstance(sparse_row, (int, float)):
                    valid_members.append((int(membership.paper_index), sparse_row))
                    weights.append(max(float(membership.community_author_share), 0.05))

            if len(valid_members) >= min_documents_for_field:
                from scipy.sparse import vstack
                from sklearn.preprocessing import normalize

                stack = vstack([item[1] for item in valid_members])
                weight_array = np.asarray(weights, dtype=float)
                centroid = np.asarray(stack.multiply(weight_array[:, None]).sum(axis=0)).ravel()
                if np.linalg.norm(centroid) > 0:
                    centroid_normalized = centroid / np.linalg.norm(centroid)
                    top_terms = _select_terms(feature_names, centroid, field_top_terms)
                    phrase_candidates = [term for term in top_terms if " " in term]
                    top_phrases = phrase_candidates[: min(10, field_top_terms)]
                    label_candidates = top_phrases + [term for term in top_terms if term not in top_phrases]
                    label_candidates = label_candidates[:field_label_terms]
                    if label_candidates:
                        field_label = " / ".join(label_candidates)
                        field_status = "inferred"

                    similarity = np.asarray(stack @ centroid_normalized).ravel()
                    for (paper_index, _), score, membership_weight in zip(valid_members, similarity, weight_array):
                        # Membership is incorporated but cannot completely swamp textual relevance.
                        final_score = float(score) * (0.65 + 0.35 * membership_weight)
                        scored.append((paper_index, final_score))
                        relevance_by_pair[(int(community), paper_index)] = final_score

        years = pd.to_numeric(unique_group["publication_year"], errors="coerce").dropna()
        citations = pd.to_numeric(unique_group["citations"], errors="coerce").fillna(0)
        journals = Counter(
            str(value).strip()
            for value in unique_group["journal"].dropna()
            if str(value).strip() and str(value).casefold() != "nan"
        )
        countries = Counter()
        institutions = Counter()
        for value in unique_group["countries"].dropna():
            countries.update(_split_pipe(value))
        for value in unique_group["institutions"].dropna():
            institutions.update(_split_pipe(value))

        topic_counts = Counter(
            _safe_int(value, 0)
            for value in unique_group["topic_id"]
            if _safe_int(value, 0) > 0
        )

        profile_rows.append(
            {
                "community": int(community),
                "inferred_field": field_label,
                "field_inference_status": field_status,
                "field_top_terms": "; ".join(top_terms),
                "field_top_phrases": "; ".join(top_phrases),
                "paper_count_any_membership": any_papers,
                "dominant_paper_count": len(dominant_group),
                "core_paper_count": len(core_group),
                "cross_community_paper_count": len(bridge_group),
                "cross_community_paper_rate": len(bridge_group) / any_papers if any_papers else 0,
                "first_publication_year": int(years.min()) if not years.empty else np.nan,
                "last_publication_year": int(years.max()) if not years.empty else np.nan,
                "mean_citations": float(citations.mean()) if len(citations) else 0,
                "total_citations": float(citations.sum()) if len(citations) else 0,
                "top_journals": " | ".join(name for name, _ in journals.most_common(8)),
                "top_institutions_from_papers": " | ".join(name for name, _ in institutions.most_common(8)),
                "top_countries_from_papers": " | ".join(name for name, _ in countries.most_common(8)),
                "top_topic_ids": " | ".join(str(topic) for topic, _ in topic_counts.most_common(5)),
                "field_extraction_note": vectorizer_error,
            }
        )

        if scored:
            score_lookup = dict(scored)
            candidates = unique_group.copy()
            candidates["community_relevance_score"] = candidates["paper_index"].map(score_lookup).fillna(0.0)
            candidates = candidates.sort_values(
                ["community_relevance_score", "is_dominant_community", "citations"],
                ascending=[False, False, False],
            ).head(representative_papers)
        else:
            candidates = unique_group.sort_values(
                ["is_dominant_community", "community_author_share", "citations"],
                ascending=[False, False, False],
            ).head(representative_papers)
            candidates["community_relevance_score"] = 0.0

        for rank, row in enumerate(candidates.itertuples(), start=1):
            representative_rows.append(
                {
                    "community": int(community),
                    "representative_rank": rank,
                    "community_relevance_score": float(row.community_relevance_score),
                    "paper_id": row.paper_id,
                    "publication_year": row.publication_year,
                    "title": row.title,
                    "journal": row.journal,
                    "doi": row.doi,
                    "doi_url": row.doi_url,
                    "citations": row.citations,
                    "community_author_share": row.community_author_share,
                    "community_author_names": row.community_author_names,
                    "is_dominant_community": row.is_dominant_community,
                    "is_cross_community_paper": row.is_cross_community_paper,
                }
            )

    community_fields = pd.DataFrame(profile_rows).sort_values(
        ["dominant_paper_count", "paper_count_any_membership"], ascending=[False, False]
    )
    community_representative_papers = pd.DataFrame(representative_rows)

    community_papers["community_relevance_score"] = [
        relevance_by_pair.get((int(row.community), int(row.paper_index)), 0.0)
        for row in community_papers.itertuples()
    ]
    field_map = community_fields.set_index("community")["inferred_field"].to_dict()
    community_papers["inferred_field"] = community_papers["community"].map(field_map).fillna("")
    community_papers = community_papers.sort_values(
        ["community", "is_dominant_community", "community_relevance_score", "publication_year"],
        ascending=[True, False, False, False],
    )

    if not community_representative_papers.empty:
        community_representative_papers["inferred_field"] = (
            community_representative_papers["community"].map(field_map).fillna("")
        )

    return {
        "community_papers": community_papers,
        "community_fields": community_fields,
        "community_representative_papers": community_representative_papers,
    }


def export_community_html(
    output_dir: Path,
    community_fields: pd.DataFrame,
    community_papers: pd.DataFrame,
    representative_papers: pd.DataFrame | None = None,
) -> None:
    """Write a searchable UTF-8 cluster catalogue and one article page per cluster."""
    if community_fields is None or community_fields.empty or community_papers is None or community_papers.empty:
        return

    output_dir = Path(output_dir)
    pages_dir = output_dir / "cluster_papers"
    pages_dir.mkdir(parents=True, exist_ok=True)
    representative_papers = representative_papers if representative_papers is not None else pd.DataFrame()

    def esc(value: Any) -> str:
        if value is None or (isinstance(value, float) and np.isnan(value)):
            return ""
        return html.escape(str(value), quote=True)

    def paper_table(frame: pd.DataFrame) -> str:
        rows = []
        for item in frame.itertuples():
            doi = str(getattr(item, "doi", "") or "")
            doi_url = str(getattr(item, "doi_url", "") or "")
            doi_html = f'<a href="{esc(doi_url)}" target="_blank">{esc(doi)}</a>' if doi_url else esc(doi)
            badge = "<span class='badge dominant'>Dominant</span>" if int(getattr(item, "is_dominant_community", 0)) else "<span class='badge associated'>Associated</span>"
            if int(getattr(item, "is_cross_community_paper", 0)):
                badge += " <span class='badge bridge'>Cross-community</span>"
            rows.append(
                "<tr>"
                f"<td>{esc(getattr(item, 'publication_year', ''))}</td>"
                f"<td><strong>{esc(getattr(item, 'title', ''))}</strong><br>{badge}</td>"
                f"<td>{esc(getattr(item, 'journal', ''))}</td>"
                f"<td>{doi_html}</td>"
                f"<td>{esc(getattr(item, 'citations', ''))}</td>"
                f"<td>{100 * _safe_number(getattr(item, 'community_author_share', 0)):.1f}%</td>"
                f"<td>{esc(getattr(item, 'community_author_names', ''))}</td>"
                "</tr>"
            )
        return "".join(rows)

    common_style = """
    <style>
    body{font-family:Arial,sans-serif;margin:0;background:#f4f6f9;color:#1f2937}
    header{background:linear-gradient(135deg,#111827,#29466f);color:white;padding:28px 5vw}
    main{max-width:1500px;margin:auto;padding:24px}
    .card{background:white;border:1px solid #e1e7ef;border-radius:14px;padding:18px;margin:14px 0;box-shadow:0 5px 18px rgba(24,39,75,.05)}
    table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:10px;border-bottom:1px solid #e6ebf2;text-align:left;vertical-align:top}th{background:#edf2f8;position:sticky;top:0}
    input{width:min(600px,90%);padding:11px;border:1px solid #cbd5e1;border-radius:8px;margin:10px 0}
    a{color:#245ca6}.badge{display:inline-block;padding:3px 7px;border-radius:10px;font-size:11px;margin-top:5px}.dominant{background:#dbeafe;color:#1e40af}.associated{background:#f3f4f6;color:#4b5563}.bridge{background:#fef3c7;color:#92400e}
    .kpis{display:flex;gap:12px;flex-wrap:wrap}.kpi{background:#f7f9fc;border-radius:9px;padding:10px 14px}.terms{line-height:1.7;color:#475569}
    </style>
    """
    filter_script = """
    <script>
    function filterRows(inputId, tableId){
      const q=document.getElementById(inputId).value.toLowerCase();
      document.querySelectorAll('#'+tableId+' tbody tr').forEach(row=>{row.style.display=row.innerText.toLowerCase().includes(q)?'':'none';});
    }
    </script>
    """

    catalogue_rows = []
    for profile in community_fields.itertuples():
        community = int(profile.community)
        cluster_frame = community_papers[community_papers["community"] == community].copy()
        reps = (
            representative_papers[representative_papers["community"] == community]
            if not representative_papers.empty and "community" in representative_papers.columns
            else pd.DataFrame()
        )
        page_name = f"community_{community:04d}.html"
        catalogue_rows.append(
            "<tr>"
            f"<td><a href='cluster_papers/{page_name}'>Cluster {community}</a></td>"
            f"<td>{esc(profile.inferred_field)}</td>"
            f"<td>{esc(profile.dominant_paper_count)}</td>"
            f"<td>{esc(profile.paper_count_any_membership)}</td>"
            f"<td>{esc(profile.cross_community_paper_count)}</td>"
            f"<td>{esc(profile.first_publication_year)}–{esc(profile.last_publication_year)}</td>"
            f"<td>{esc(profile.top_journals)}</td>"
            "</tr>"
        )

        rep_html = ""
        if not reps.empty:
            rep_html = (
                "<section class='card'><h2>Representative papers</h2>"
                "<table><thead><tr><th>Year</th><th>Paper</th><th>Journal</th><th>DOI</th><th>Citations</th><th>Cluster share</th><th>Cluster authors</th></tr></thead>"
                f"<tbody>{paper_table(reps)}</tbody></table></section>"
            )

        page = f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Cluster {community}</title>{common_style}</head><body>
        <header><h1>Cluster {community}</h1><p>{esc(profile.inferred_field)}</p></header><main>
        <p><a href='../cluster_catalog.html'>← Cluster catalogue</a></p>
        <section class='card'><div class='kpis'><div class='kpi'>Dominant papers: <strong>{esc(profile.dominant_paper_count)}</strong></div><div class='kpi'>All associated papers: <strong>{esc(profile.paper_count_any_membership)}</strong></div><div class='kpi'>Cross-community papers: <strong>{esc(profile.cross_community_paper_count)}</strong></div></div>
        <h3>Inferred research field</h3><p><strong>{esc(profile.inferred_field)}</strong></p><p class='terms'>{esc(profile.field_top_terms)}</p><p>Top journals: {esc(profile.top_journals)}</p><p>Top institutions: {esc(profile.top_institutions_from_papers)}</p><p>Top countries: {esc(profile.top_countries_from_papers)}</p></section>
        {rep_html}
        <section class='card'><h2>All papers associated with this cluster</h2><input id='paperSearch' onkeyup="filterRows('paperSearch','paperTable')" placeholder='Search title, author, journal, DOI...'><div style='overflow:auto;max-height:75vh'><table id='paperTable'><thead><tr><th>Year</th><th>Paper</th><th>Journal</th><th>DOI</th><th>Citations</th><th>Cluster share</th><th>Cluster authors</th></tr></thead><tbody>{paper_table(cluster_frame)}</tbody></table></div></section>
        </main>{filter_script}</body></html>"""
        (pages_dir / page_name).write_text(page, encoding="utf-8", newline="\n")

    catalogue = f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Cluster paper catalogue</title>{common_style}</head><body>
    <header><h1>Research-cluster paper catalogue</h1><p>Each field label is inferred from titles, abstracts and keywords using a discriminative TF-IDF profile.</p></header><main>
    <section class='card'><input id='clusterSearch' onkeyup="filterRows('clusterSearch','clusterTable')" placeholder='Search cluster, field, journal...'><div style='overflow:auto;max-height:80vh'><table id='clusterTable'><thead><tr><th>Cluster</th><th>Inferred field</th><th>Dominant papers</th><th>Associated papers</th><th>Cross-cluster</th><th>Years</th><th>Top journals</th></tr></thead><tbody>{''.join(catalogue_rows)}</tbody></table></div></section>
    </main>{filter_script}</body></html>"""
    (output_dir / "cluster_catalog.html").write_text(catalogue, encoding="utf-8", newline="\n")
