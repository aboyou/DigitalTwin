from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import networkx as nx
import pandas as pd

from author_analysis.config import AnalysisConfig
from author_analysis.visualization import Visualizer


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Rebuild figures and interactive HTML from an existing result folder "
            "without re-reading the SQLite database or recomputing centralities."
        )
    )
    parser.add_argument(
        "results",
        type=Path,
        help="Existing result directory, for example resultsLight",
    )
    parser.add_argument(
        "--database",
        type=Path,
        default=Path("placeholder.db"),
        help="Only stored in the config; the database is not read.",
    )
    parser.add_argument("--static-network-top-nodes", type=int, default=350)
    parser.add_argument("--interactive-network-top-nodes", type=int, default=3000)
    parser.add_argument("--community-html-limit", type=int, default=10)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    results = args.results.resolve()
    graph_path = results / "networks" / "coauthorship.gexf"
    tables_dir = results / "tables"
    manifest_path = results / "manifest.json"

    if not graph_path.exists():
        raise FileNotFoundError(f"GEXF file not found: {graph_path}")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )

    graph = nx.read_gexf(graph_path)
    data: dict[str, pd.DataFrame] = {}
    for csv_path in tables_dir.glob("*.csv"):
        try:
            data[csv_path.stem] = pd.read_csv(csv_path, low_memory=False)
        except Exception as exc:
            logging.getLogger("rebuild_visuals").warning(
                "Could not read %s: %s", csv_path.name, exc
            )

    network_summary = {}
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        network_summary = manifest.get("network_summary", {})

    config = AnalysisConfig(
        db_path=args.database,
        output_dir=results,
        static_network_top_nodes=args.static_network_top_nodes,
        interactive_network_top_nodes=args.interactive_network_top_nodes,
        community_html_limit=args.community_html_limit,
    )

    Visualizer(config, graph, data, network_summary).create_all()
    logging.getLogger("rebuild_visuals").info(
        "Visual outputs rebuilt in %s", results
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
