@echo off
setlocal
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
 .venv\Scripts\python.exe app.py sample_articles.db --output demo_output
) else (
 python app.py sample_articles.db --output demo_output
)
echo Open demo_output\interactive\dashboard.html
pause
