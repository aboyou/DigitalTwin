@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
 echo Usage: run_analysis.bat "C:\path\to\articles.db"
 pause
 exit /b 1
)
if exist .venv\Scripts\python.exe (
 .venv\Scripts\python.exe app.py "%~1" --output author_analysis_output
) else (
 python app.py "%~1" --output author_analysis_output
)
if errorlevel 1 (
 echo Analysis failed. Check author_analysis_output\analysis.log
 pause
 exit /b 1
)
echo Open author_analysis_output\interactive\dashboard.html
echo Open author_analysis_output\tables\analysis_report.xlsx
echo Open author_analysis_output\networks\coauthorship.gexf in Gephi
pause
